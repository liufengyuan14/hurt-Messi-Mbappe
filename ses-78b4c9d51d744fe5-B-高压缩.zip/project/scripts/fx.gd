class_name Fx
extends Node3D
## Particles, floating comic words, damage numbers, flying debris and stick-on patches.

enum Cell { DOT, STAR, PUFF, PLUS }
enum Patch { BRUISE, EGG, SLIPPER, SOOT, SLAP, BALL, BANDAID, DIRT }

var font: Font
var fx_mats: Array[StandardMaterial3D] = []
var patch_mats: Array[StandardMaterial3D] = []
var quad: QuadMesh
var patch_quad: QuadMesh
var debris: Array = []
var main


func setup(big_font: Font) -> void:
	font = big_font
	quad = QuadMesh.new()
	quad.size = Vector2(1, 1)
	patch_quad = QuadMesh.new()
	patch_quad.size = Vector2(1, 1)
	var fx_tex := load("res://assets/fx.png") as Texture2D
	for i in 4:
		var m := StandardMaterial3D.new()
		m.albedo_texture = fx_tex
		m.uv1_scale = Vector3(0.25, 1, 1)
		m.uv1_offset = Vector3(i * 0.25, 0, 0)
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
		m.vertex_color_use_as_albedo = true
		m.cull_mode = BaseMaterial3D.CULL_DISABLED
		m.no_depth_test = i == Cell.STAR
		m.render_priority = 2
		fx_mats.append(m)
	var p_tex := load("res://assets/patches.png") as Texture2D
	for i in 8:
		var m := StandardMaterial3D.new()
		m.albedo_texture = p_tex
		m.uv1_scale = Vector3(0.25, 0.5, 1)
		m.uv1_offset = Vector3((i % 4) * 0.25, (i / 4) * 0.5, 0)
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.cull_mode = BaseMaterial3D.CULL_DISABLED
		m.roughness = 0.8
		m.render_priority = 1
		patch_mats.append(m)


func burst(pos: Vector3, cell: int, count: int, color: Color, speed: float, size: float,
		gravity := -6.0, life := 0.6, spread := 180.0, dir := Vector3.UP) -> void:
	var p := CPUParticles3D.new()
	p.one_shot = true
	p.amount = count
	p.lifetime = life
	p.explosiveness = 1.0
	p.randomness = 0.5
	p.mesh = quad
	p.material_override = fx_mats[cell]
	p.direction = dir
	p.spread = spread
	p.initial_velocity_min = speed * 0.4
	p.initial_velocity_max = speed
	p.gravity = Vector3(0, gravity, 0)
	p.damping_min = 1.0
	p.damping_max = 3.0
	p.scale_amount_min = size * 0.6
	p.scale_amount_max = size
	var sc := Curve.new()
	sc.add_point(Vector2(0, 1))
	sc.add_point(Vector2(1, 0.2))
	p.scale_amount_curve = sc
	if cell == Cell.PUFF:
		var gc := Curve.new()
		gc.add_point(Vector2(0, 0.5))
		gc.add_point(Vector2(1, 1.6))
		p.scale_amount_curve = gc
	var g := Gradient.new()
	g.set_color(0, color)
	g.set_color(1, Color(color.r, color.g, color.b, 0))
	p.color_ramp = g
	p.angle_min = 0
	p.angle_max = 360
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(p)
	p.global_position = pos
	p.emitting = true
	get_tree().create_timer(life + 0.3, false).timeout.connect(p.queue_free)


func spark(pos: Vector3, color := Color(1, 0.9, 0.4), n := 10, power := 1.0) -> void:
	burst(pos, Cell.STAR, n, color, 3.5 * power, 0.12 * power, -4.0, 0.45)
	burst(pos, Cell.DOT, 1, Color(1, 1, 0.9, 0.9), 0.0, 0.6 * power, 0.0, 0.12)


func dust(pos: Vector3, n := 10, power := 1.0) -> void:
	burst(pos + Vector3(0, 0.1, 0), Cell.PUFF, n, Color(0.78, 0.72, 0.6, 0.75), 2.2 * power, 0.45 * power, 0.5, 0.9, 80.0)


func smoke(pos: Vector3, n := 6, power := 1.0) -> void:
	burst(pos, Cell.PUFF, n, Color(0.25, 0.24, 0.24, 0.85), 1.4 * power, 0.5 * power, 1.2, 1.2, 70.0)


func word(pos: Vector3, text: String, color: Color, size := 1.0) -> void:
	var l := _label(text, 96, color, Color(0.1, 0.05, 0.1))
	add_child(l)
	l.global_position = pos + Vector3(randf_range(-0.2, 0.2), randf_range(0.1, 0.3), 0.1)
	l.scale = Vector3.ONE * 0.2 * size
	var tw := create_tween()
	tw.tween_property(l, "scale", Vector3.ONE * size, 0.16).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_interval(0.35)
	tw.set_parallel(true)
	tw.tween_property(l, "modulate:a", 0.0, 0.3)
	tw.tween_property(l, "outline_modulate:a", 0.0, 0.3)
	tw.tween_property(l, "position:y", l.position.y + 0.3, 0.3)
	tw.chain().tween_callback(l.queue_free)


func number(pos: Vector3, amount: float, crit: bool) -> void:
	var txt := "-%d" % roundi(amount)
	var col := Color(1, 0.3, 0.25)
	var sz := 0.7
	if crit:
		txt = "暴击 " + txt
		col = Color(1, 0.85, 0.15)
		sz = 1.0
	var l := _label(txt, 64, col, Color(0.15, 0, 0))
	add_child(l)
	l.global_position = pos + Vector3(randf_range(-0.25, 0.25), 0.15, 0.2)
	l.scale = Vector3.ONE * sz
	var tw := create_tween().set_parallel(true)
	tw.tween_property(l, "position:y", l.position.y + 0.7, 0.9).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)
	tw.tween_property(l, "modulate:a", 0.0, 0.4).set_delay(0.5)
	tw.tween_property(l, "outline_modulate:a", 0.0, 0.4).set_delay(0.5)
	tw.chain().tween_callback(l.queue_free)


func _label(text: String, fsize: int, color: Color, outline: Color) -> Label3D:
	var l := Label3D.new()
	l.font = font
	l.text = text
	l.font_size = fsize
	l.outline_size = 22
	l.modulate = color
	l.outline_modulate = outline
	l.pixel_size = 0.004
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.no_depth_test = true
	l.render_priority = 10
	l.outline_render_priority = 9
	return l


## Sticks a decal-like quad on a body part. lpos/ln are in the part's local space.
func patch(part: Node3D, lpos: Vector3, ln: Vector3, kind: int, size: float, owner_dummy = null) -> MeshInstance3D:
	var q := MeshInstance3D.new()
	q.mesh = patch_quad
	q.material_override = patch_mats[kind]
	q.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	part.add_child(q)
	var z := ln.normalized()
	var x := z.cross(Vector3.UP)
	if x.length() < 0.1:
		x = z.cross(Vector3.RIGHT)
	x = x.normalized()
	var y := z.cross(x)
	var b := Basis(z, randf() * TAU) * Basis(x, y, z)
	q.transform = Transform3D(b.scaled(Vector3.ONE * size), lpos + z * 0.014)
	q.scale = Vector3.ONE * size * 0.3
	create_tween().tween_property(q, "scale", Vector3.ONE * size, 0.12).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	if owner_dummy:
		owner_dummy.add_patch(q)
	return q


func ground_patch(pos: Vector3, kind: int, size: float, life := 8.0) -> void:
	var q := patch(self, Vector3(pos.x, 0.0, pos.z), Vector3.UP, kind, size)
	var tw := create_tween()
	tw.tween_interval(life)
	tw.tween_property(q, "scale", Vector3.ONE * 0.01, 0.6)
	tw.tween_callback(q.queue_free)


func throw_debris(node: Node3D, pos: Vector3, vel: Vector3, life := 2.5, sound := "") -> void:
	add_child(node)
	node.global_position = pos
	debris.append({"node": node, "vel": vel, "spin": Vector3(randf_range(-15, 15), randf_range(-15, 15), randf_range(-15, 15)),
		"life": life, "max": life, "sound": sound})


func make_bit(color: Color, size: Vector3) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.4
	mi.material_override = m
	return mi


func _process(dt: float) -> void:
	for d in debris.duplicate():
		var n := d["node"] as Node3D
		if not is_instance_valid(n):
			debris.erase(d)
			continue
		var v: Vector3 = d["vel"]
		v.y -= 12.0 * dt
		var p := n.global_position + v * dt
		if p.y < 0.03:
			p.y = 0.03
			if v.y < -1.5 and d["sound"] != "" and main:
				main.sfx(d["sound"], -10.0, randf_range(0.9, 1.3))
			v = Vector3(v.x * 0.6, -v.y * 0.35, v.z * 0.6)
			d["spin"] = (d["spin"] as Vector3) * 0.6
		d["vel"] = v
		n.global_position = p
		n.rotation += (d["spin"] as Vector3) * dt
		d["life"] = float(d["life"]) - dt
		if d["life"] < 0.4:
			n.scale = Vector3.ONE * maxf(0.01, float(d["life"]) / 0.4)
		if d["life"] <= 0.0:
			n.queue_free()
			debris.erase(d)
