class_name World
extends RefCounted
## Builds the static stadium scene (pitch, goal, stands, crowd, lights).

const GRASS_SHADER := """
shader_type spatial;
render_mode cull_back;
uniform sampler2D noise_tex : source_color, repeat_enable, filter_linear_mipmap;
varying vec3 wpos;
float ln(float d) { return 1.0 - smoothstep(0.045, 0.075, abs(d)); }
float seg_x(vec2 p, float z, float x0, float x1) { return ln(p.y - z) * step(x0, p.x) * step(p.x, x1); }
float seg_z(vec2 p, float x, float z0, float z1) { return ln(p.x - x) * step(z0, p.y) * step(p.y, z1); }
void vertex() { wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz; }
void fragment() {
	vec2 p = wpos.xz;
	float stripe = step(0.5, fract((p.y + 5.5) / 5.0));
	vec3 dark = vec3(0.045, 0.15, 0.035);
	vec3 light = vec3(0.07, 0.21, 0.05);
	float n = texture(noise_tex, p * 0.35).r * 0.6 + texture(noise_tex, p * 0.07).r * 0.4;
	vec3 col = mix(dark, light, stripe) * (0.8 + 0.35 * n);
	float g = -5.5;
	float l = 0.0;
	l = max(l, seg_x(p, g, -40.0, 40.0));
	l = max(l, seg_x(p, g + 5.5, -9.16, 9.16));
	l = max(l, seg_z(p, -9.16, g, g + 5.5));
	l = max(l, seg_z(p, 9.16, g, g + 5.5));
	l = max(l, seg_x(p, g + 16.5, -20.16, 20.16));
	l = max(l, seg_z(p, -20.16, g, g + 16.5));
	l = max(l, seg_z(p, 20.16, g, g + 16.5));
	float spot = 1.0 - smoothstep(0.1, 0.13, length(p - vec2(0.0, g + 11.0)));
	l = max(l, spot);
	col = mix(col, vec3(0.75), l * 0.9);
	ALBEDO = col;
	ROUGHNESS = 0.92;
	SPECULAR = 0.2;
}
"""

const CROWD_SHADER := """
shader_type spatial;
render_mode cull_disabled;
uniform float excite = 0.2;
varying vec3 col;
void vertex() {
	float ph = INSTANCE_CUSTOM.r * 6.2831;
	float speed = 6.0 + INSTANCE_CUSTOM.g * 6.0;
	float j = max(0.0, sin(TIME * speed + ph));
	float amp = mix(0.03, 0.28, excite) * (0.4 + INSTANCE_CUSTOM.b);
	float arms = step(0.5, VERTEX.y) * step(0.15, abs(VERTEX.x));
	VERTEX.y += j * amp;
	VERTEX.y += arms * excite * 0.12 * sin(TIME * speed * 1.3 + ph);
	col = COLOR.rgb;
}
void fragment() {
	ALBEDO = col;
	ROUGHNESS = 0.9;
}
"""

const AD_SHADER := """
shader_type spatial;
render_mode unshaded;
uniform sampler2D ads : source_color, repeat_enable, filter_linear_mipmap;
uniform float rows = 4.0;
void fragment() {
	float t = floor(TIME / 4.0);
	float row = mod(t, rows);
	vec2 uv = vec2(fract(UV.x * 6.0 + TIME * 0.08), (UV.y + row) / rows);
	ALBEDO = texture(ads, uv).rgb * 1.15;
}
"""


static func build(root: Node3D, kit: Dictionary) -> Dictionary:
	var out := {}
	# environment
	var env := Environment.new()
	var sky := Sky.new()
	var sm := ProceduralSkyMaterial.new()
	sm.sky_top_color = Color(0.22, 0.42, 0.78)
	sm.sky_horizon_color = Color(0.72, 0.82, 0.93)
	sm.ground_bottom_color = Color(0.2, 0.25, 0.2)
	sm.ground_horizon_color = Color(0.72, 0.8, 0.86)
	sm.sun_angle_max = 20.0
	sky.sky_material = sm
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.55
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 0.95
	env.fog_enabled = false
	var we := WorldEnvironment.new()
	we.environment = env
	root.add_child(we)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52, -35, 0)
	sun.light_energy = 1.0
	sun.light_color = Color(1.0, 0.96, 0.9)
	sun.shadow_enabled = true
	sun.shadow_bias = 0.03
	sun.shadow_normal_bias = 1.5
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	sun.directional_shadow_max_distance = 22.0
	root.add_child(sun)
	var fill := DirectionalLight3D.new()
	fill.rotation_degrees = Vector3(-25, 150, 0)
	fill.light_energy = 0.25
	fill.light_color = Color(0.75, 0.85, 1.0)
	root.add_child(fill)

	# pitch
	var ground := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(90, 90)
	ground.mesh = pm
	var gmat := ShaderMaterial.new()
	var gsh := Shader.new()
	gsh.code = GRASS_SHADER
	gmat.shader = gsh
	gmat.set_shader_parameter("noise_tex", load("res://assets/grass.png"))
	ground.material_override = gmat
	root.add_child(ground)

	# goal
	if kit.has("goal"):
		var goal := (kit["goal"] as Node3D).duplicate() as Node3D
		root.add_child(goal)
		goal.position = Vector3(0, 0, -5.5)
		goal.rotation = Vector3.ZERO

	# ad boards behind goal and along the sides
	var ad_mat := ShaderMaterial.new()
	var ash := Shader.new()
	ash.code = AD_SHADER
	ad_mat.shader = ash
	ad_mat.set_shader_parameter("ads", load("res://assets/ads.png"))
	_board(root, ad_mat, Vector3(0, 0.5, -9.0), 36.0, 0.0)
	_board(root, ad_mat, Vector3(-15.5, 0.5, -1.0), 16.0, PI / 2)
	_board(root, ad_mat, Vector3(15.5, 0.5, -1.0), 16.0, -PI / 2)

	# stands
	var stand_mat := StandardMaterial3D.new()
	stand_mat.albedo_color = Color(0.24, 0.27, 0.34)
	stand_mat.roughness = 0.9
	var seat_mat := StandardMaterial3D.new()
	seat_mat.albedo_color = Color(0.75, 0.12, 0.15)
	var crowd_pts: Array = []
	_stand(root, stand_mat, seat_mat, Vector3(0, 0, -10.0), 40.0, 0.0, crowd_pts)
	_stand(root, stand_mat, seat_mat, Vector3(-16.5, 0, -1.0), 20.0, PI / 2, crowd_pts)
	_stand(root, stand_mat, seat_mat, Vector3(16.5, 0, -1.0), 20.0, -PI / 2, crowd_pts)
	# roof
	var roof := MeshInstance3D.new()
	var rb := BoxMesh.new()
	rb.size = Vector3(44, 0.4, 6)
	roof.mesh = rb
	roof.material_override = stand_mat
	roof.position = Vector3(0, 11.5, -18.5)
	roof.rotation.x = -0.12
	root.add_child(roof)

	# crowd
	if kit.has("spectator"):
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.use_colors = true
		mm.use_custom_data = true
		mm.mesh = (kit["spectator"] as MeshInstance3D).mesh
		mm.instance_count = crowd_pts.size()
		var palette := [Color(0.95, 0.95, 0.95), Color(0.45, 0.7, 0.95), Color(0.12, 0.17, 0.4),
			Color(0.85, 0.15, 0.2), Color(0.98, 0.8, 0.2), Color(0.2, 0.55, 0.3), Color(0.9, 0.5, 0.15),
			Color(0.55, 0.3, 0.65), Color(0.15, 0.15, 0.18)]
		for i in crowd_pts.size():
			var t: Transform3D = crowd_pts[i]
			mm.set_instance_transform(i, t)
			var c: Color = palette[randi() % palette.size()]
			mm.set_instance_color(i, c * randf_range(0.8, 1.05))
			mm.set_instance_custom_data(i, Color(randf(), randf(), randf(), 0))
		var mmi := MultiMeshInstance3D.new()
		mmi.multimesh = mm
		var cmat := ShaderMaterial.new()
		var csh := Shader.new()
		csh.code = CROWD_SHADER
		cmat.shader = csh
		mmi.material_override = cmat
		mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		root.add_child(mmi)
		out["crowd_mat"] = cmat

	# floodlight towers
	var pole_mat := StandardMaterial3D.new()
	pole_mat.albedo_color = Color(0.55, 0.57, 0.6)
	pole_mat.metallic = 0.6
	var lamp_mat := StandardMaterial3D.new()
	lamp_mat.albedo_color = Color(1, 1, 0.9)
	lamp_mat.emission_enabled = true
	lamp_mat.emission = Color(1, 0.97, 0.85)
	lamp_mat.emission_energy_multiplier = 2.0
	for x in [-22.0, 22.0]:
		var pole := MeshInstance3D.new()
		var cy := CylinderMesh.new()
		cy.top_radius = 0.25
		cy.bottom_radius = 0.4
		cy.height = 20.0
		pole.mesh = cy
		pole.material_override = pole_mat
		pole.position = Vector3(x, 10.0, -20.0)
		root.add_child(pole)
		var lamp := MeshInstance3D.new()
		var lb := BoxMesh.new()
		lb.size = Vector3(4.0, 2.4, 0.4)
		lamp.mesh = lb
		lamp.material_override = lamp_mat
		lamp.position = Vector3(x, 20.5, -19.6)
		lamp.rotation = Vector3(0.35, -signf(x) * 0.5, 0)
		root.add_child(lamp)
	return out


static func _board(root: Node3D, mat: Material, pos: Vector3, length: float, yaw: float) -> void:
	var mi := MeshInstance3D.new()
	var q := QuadMesh.new()
	q.size = Vector2(length, 0.95)
	mi.mesh = q
	mi.material_override = mat
	mi.position = pos
	mi.rotation.y = yaw
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(mi)
	var back := MeshInstance3D.new()
	var b := BoxMesh.new()
	b.size = Vector3(length, 1.0, 0.12)
	back.mesh = b
	var bm := StandardMaterial3D.new()
	bm.albedo_color = Color(0.1, 0.1, 0.12)
	back.material_override = bm
	back.position = pos + Basis(Vector3.UP, yaw) * Vector3(0, 0, -0.08)
	back.rotation.y = yaw
	root.add_child(back)


static func _stand(root: Node3D, mat: Material, seat: Material, origin: Vector3, width: float, yaw: float, pts: Array) -> void:
	var basis := Basis(Vector3.UP, yaw)
	var rows := 9
	for r in rows:
		var step := MeshInstance3D.new()
		var b := BoxMesh.new()
		var h := 0.9 + r * 0.9
		b.size = Vector3(width, h, 1.1)
		step.mesh = b
		step.material_override = mat if r % 2 == 0 else seat
		step.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		var local := Vector3(0, h * 0.5, -r * 1.1)
		step.position = origin + basis * local
		step.rotation.y = yaw
		root.add_child(step)
		var n := int(width / 0.62)
		for k in n:
			if randf() < 0.12:
				continue
			var x := -width * 0.5 + (k + 0.5) * width / n + randf_range(-0.1, 0.1)
			var p := origin + basis * Vector3(x, h, -r * 1.1 + 0.15)
			var s := randf_range(0.85, 1.1)
			var t := Transform3D(Basis(Vector3.UP, yaw + randf_range(-0.25, 0.25)).scaled(Vector3.ONE * s), p)
			pts.append(t)
