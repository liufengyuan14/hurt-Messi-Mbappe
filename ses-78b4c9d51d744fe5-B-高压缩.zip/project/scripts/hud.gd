class_name Hud
extends CanvasLayer
## On-screen UI: HP panels, relief meter, tool bar, target selector, banners.

signal tool_selected(i: int)
signal target_selected(i: int)
signal gang_pressed
signal heal_pressed
signal sound_toggled

const C_TURTLE := Color(0.96, 0.96, 0.98)
const C_MOUSE := Color(0.45, 0.72, 0.95)
const GOLD := Color(1.0, 0.8, 0.2)

var font: Font
var root: Control
var tool_btns: Array[Button] = []
var target_btns: Array[Button] = []
var hp_bars: Array[ProgressBar] = []
var hp_labels: Array[Label] = []
var ko_labels: Array[Label] = []
var hp_shown := [100.0, 100.0]
var relief_bar: ProgressBar
var relief_label: Label
var combo_label: Label
var banner_label: Label
var banner_tw: Tween
var flash_rect: ColorRect
var hint: Label
var cursor_icon: TextureRect
var sound_btn: Button
var tool_name_label: Label
var icons: Array[AtlasTexture] = []
var combo_shown := 0


func _box(bg: Color, border := Color(1, 1, 1, 0.12), bw := 2, radius := 14) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(bw)
	s.set_corner_radius_all(radius)
	s.content_margin_left = 10
	s.content_margin_right = 10
	s.content_margin_top = 6
	s.content_margin_bottom = 6
	s.shadow_color = Color(0, 0, 0, 0.25)
	s.shadow_size = 4
	return s


func build(f: Font, icon_tex: Texture2D, tools: Array, names: Array) -> void:
	font = f
	layer = 5
	var theme := Theme.new()
	theme.default_font = f
	theme.default_font_size = 20
	theme.set_stylebox("normal", "Button", _box(Color(0.07, 0.09, 0.15, 0.85)))
	theme.set_stylebox("hover", "Button", _box(Color(0.16, 0.2, 0.3, 0.92), Color(1, 1, 1, 0.35)))
	theme.set_stylebox("pressed", "Button", _box(Color(0.42, 0.26, 0.04, 0.95), GOLD, 3))
	theme.set_stylebox("hover_pressed", "Button", _box(Color(0.5, 0.32, 0.06, 0.95), GOLD, 3))
	theme.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	theme.set_color("font_color", "Button", Color(0.95, 0.95, 0.95))
	theme.set_color("font_pressed_color", "Button", Color(1, 0.95, 0.7))
	theme.set_color("font_hover_pressed_color", "Button", Color(1, 0.95, 0.7))
	theme.set_stylebox("panel", "PanelContainer", _box(Color(0.05, 0.07, 0.12, 0.72), Color(1, 1, 1, 0.1), 2, 16))
	theme.set_color("font_outline_color", "Label", Color(0, 0, 0, 0.85))
	theme.set_constant("outline_size", "Label", 6)

	root = Control.new()
	root.theme = theme
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	flash_rect = ColorRect.new()
	flash_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	flash_rect.color = Color(1, 1, 1, 0)
	flash_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(flash_rect)

	# HP panels
	for i in 2:
		var p := PanelContainer.new()
		p.mouse_filter = Control.MOUSE_FILTER_IGNORE
		root.add_child(p)
		if i == 0:
			p.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT, Control.PRESET_MODE_MINSIZE, 14)
		else:
			p.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 14)
			p.grow_horizontal = Control.GROW_DIRECTION_BEGIN
		var v := VBoxContainer.new()
		v.mouse_filter = Control.MOUSE_FILTER_IGNORE
		v.add_theme_constant_override("separation", 4)
		p.add_child(v)
		var nl := Label.new()
		nl.text = names[i]
		nl.add_theme_font_size_override("font_size", 26)
		nl.add_theme_color_override("font_color", C_TURTLE if i == 0 else C_MOUSE)
		v.add_child(nl)
		var bar := ProgressBar.new()
		bar.custom_minimum_size = Vector2(300, 26)
		bar.max_value = 100
		bar.value = 100
		bar.show_percentage = false
		var bg := _box(Color(0.15, 0.03, 0.05, 0.9), Color(0, 0, 0, 0.6), 2, 8)
		var fill := _box(Color(0.35, 0.85, 0.35) if i == 0 else Color(0.35, 0.75, 1.0), Color(1, 1, 1, 0.4), 2, 8)
		bar.add_theme_stylebox_override("background", bg)
		bar.add_theme_stylebox_override("fill", fill)
		bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
		v.add_child(bar)
		var h := HBoxContainer.new()
		h.mouse_filter = Control.MOUSE_FILTER_IGNORE
		v.add_child(h)
		var hl := Label.new()
		hl.text = "血量 100"
		hl.add_theme_font_size_override("font_size", 18)
		hl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		h.add_child(hl)
		var kl := Label.new()
		kl.text = "被打倒 0 次"
		kl.add_theme_font_size_override("font_size", 18)
		kl.add_theme_color_override("font_color", GOLD)
		h.add_child(kl)
		hp_bars.append(bar)
		hp_labels.append(hl)
		ko_labels.append(kl)

	# title + relief meter
	var top := VBoxContainer.new()
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP, Control.PRESET_MODE_MINSIZE, 10)
	top.grow_horizontal = Control.GROW_DIRECTION_BOTH
	top.alignment = BoxContainer.ALIGNMENT_BEGIN
	root.add_child(top)
	var title := Label.new()
	title.text = "暴打神龟呦西"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 40)
	title.add_theme_color_override("font_color", GOLD)
	title.add_theme_constant_override("outline_size", 12)
	top.add_child(title)
	relief_bar = ProgressBar.new()
	relief_bar.custom_minimum_size = Vector2(330, 18)
	relief_bar.max_value = 1.0
	relief_bar.step = 0.0
	relief_bar.show_percentage = false
	relief_bar.add_theme_stylebox_override("background", _box(Color(0.1, 0.1, 0.12, 0.85), Color(0, 0, 0, 0.6), 2, 8))
	relief_bar.add_theme_stylebox_override("fill", _box(Color(1.0, 0.45, 0.2), Color(1, 1, 1, 0.4), 2, 8))
	relief_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_child(relief_bar)
	relief_label = Label.new()
	relief_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	relief_label.add_theme_font_size_override("font_size", 18)
	relief_label.text = "解气值 Lv.0 还没解气"
	top.add_child(relief_label)

	# tool bar
	var tb := PanelContainer.new()
	root.add_child(tb)
	tb.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM, Control.PRESET_MODE_MINSIZE, 12)
	tb.grow_horizontal = Control.GROW_DIRECTION_BOTH
	tb.grow_vertical = Control.GROW_DIRECTION_BEGIN
	var tv := VBoxContainer.new()
	tv.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tb.add_child(tv)
	tool_name_label = Label.new()
	tool_name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tool_name_label.add_theme_font_size_override("font_size", 18)
	tool_name_label.add_theme_color_override("font_color", Color(1, 0.92, 0.7))
	tv.add_child(tool_name_label)
	var th := HBoxContainer.new()
	th.mouse_filter = Control.MOUSE_FILTER_IGNORE
	th.add_theme_constant_override("separation", 8)
	tv.add_child(th)
	var group := ButtonGroup.new()
	for i in tools.size():
		var at := AtlasTexture.new()
		at.atlas = icon_tex
		at.region = Rect2((i % 4) * 256, (i / 4) * 256, 256, 256)
		icons.append(at)
		var b := Button.new()
		b.toggle_mode = true
		b.button_group = group
		b.icon = at
		b.expand_icon = true
		b.text = "%d %s" % [i + 1, tools[i]["name"]]
		b.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
		b.vertical_icon_alignment = VERTICAL_ALIGNMENT_TOP
		b.add_theme_font_size_override("font_size", 16)
		b.custom_minimum_size = Vector2(104, 110)
		b.focus_mode = Control.FOCUS_NONE
		b.pressed.connect(func(): tool_selected.emit(i))
		th.add_child(b)
		tool_btns.append(b)

	# right column: targets + actions
	var rp := PanelContainer.new()
	root.add_child(rp)
	rp.set_anchors_and_offsets_preset(Control.PRESET_CENTER_RIGHT, Control.PRESET_MODE_MINSIZE, 14)
	rp.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	rp.grow_vertical = Control.GROW_DIRECTION_BOTH
	var rv := VBoxContainer.new()
	rv.mouse_filter = Control.MOUSE_FILTER_IGNORE
	rv.add_theme_constant_override("separation", 8)
	rp.add_child(rv)
	var tl := Label.new()
	tl.text = "选人开揍"
	tl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tl.add_theme_color_override("font_color", GOLD)
	rv.add_child(tl)
	var tg := ButtonGroup.new()
	var tnames := ["揍神龟", "揍呦西", "一起揍"]
	for i in 3:
		var b := Button.new()
		b.toggle_mode = true
		b.button_group = tg
		b.text = tnames[i]
		b.custom_minimum_size = Vector2(150, 46)
		b.focus_mode = Control.FOCUS_NONE
		b.pressed.connect(func(): target_selected.emit(i))
		rv.add_child(b)
		target_btns.append(b)
	var sep := HSeparator.new()
	sep.mouse_filter = Control.MOUSE_FILTER_IGNORE
	rv.add_child(sep)
	var gang := Button.new()
	gang.text = "呼叫围攻！"
	gang.custom_minimum_size = Vector2(150, 54)
	gang.focus_mode = Control.FOCUS_NONE
	gang.add_theme_stylebox_override("normal", _box(Color(0.7, 0.1, 0.12, 0.92), Color(1, 0.8, 0.5, 0.6), 2))
	gang.add_theme_stylebox_override("hover", _box(Color(0.85, 0.18, 0.18, 0.95), Color(1, 0.9, 0.6, 0.9), 2))
	gang.add_theme_font_size_override("font_size", 22)
	gang.pressed.connect(func(): gang_pressed.emit())
	rv.add_child(gang)
	var heal := Button.new()
	heal.text = "治疗复活"
	heal.custom_minimum_size = Vector2(150, 46)
	heal.focus_mode = Control.FOCUS_NONE
	heal.add_theme_stylebox_override("normal", _box(Color(0.1, 0.45, 0.22, 0.9)))
	heal.add_theme_stylebox_override("hover", _box(Color(0.15, 0.58, 0.3, 0.95), Color(1, 1, 1, 0.4)))
	heal.pressed.connect(func(): heal_pressed.emit())
	rv.add_child(heal)
	sound_btn = Button.new()
	sound_btn.text = "音效：开"
	sound_btn.custom_minimum_size = Vector2(150, 40)
	sound_btn.focus_mode = Control.FOCUS_NONE
	sound_btn.add_theme_font_size_override("font_size", 17)
	sound_btn.pressed.connect(func(): sound_toggled.emit())
	rv.add_child(sound_btn)

	combo_label = Label.new()
	combo_label.add_theme_font_size_override("font_size", 54)
	combo_label.add_theme_color_override("font_color", Color(1, 0.85, 0.25))
	combo_label.add_theme_constant_override("outline_size", 14)
	combo_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_LEFT, Control.PRESET_MODE_MINSIZE, 30)
	combo_label.offset_top = -40
	combo_label.offset_bottom = 40
	combo_label.pivot_offset = Vector2(60, 40)
	combo_label.visible = false
	root.add_child(combo_label)

	banner_label = Label.new()
	banner_label.set_anchors_preset(Control.PRESET_CENTER)
	banner_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	banner_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	banner_label.add_theme_font_size_override("font_size", 58)
	banner_label.add_theme_constant_override("outline_size", 16)
	banner_label.anchor_left = 0.0
	banner_label.anchor_right = 1.0
	banner_label.anchor_top = 0.27
	banner_label.anchor_bottom = 0.27
	banner_label.offset_top = -50
	banner_label.offset_bottom = 50
	banner_label.modulate.a = 0.0
	root.add_child(banner_label)

	hint = Label.new()
	hint.text = "点击角色开打 · 按住连续暴打 · 数字键1-8换工具 · 空格呼叫围攻"
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.add_theme_font_size_override("font_size", 22)
	hint.anchor_left = 0.0
	hint.anchor_right = 1.0
	hint.anchor_top = 1.0
	hint.anchor_bottom = 1.0
	hint.offset_top = -205
	hint.offset_bottom = -175
	root.add_child(hint)

	cursor_icon = TextureRect.new()
	cursor_icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cursor_icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	cursor_icon.size = Vector2(64, 64)
	cursor_icon.modulate = Color(1, 1, 1, 0.9)
	root.add_child(cursor_icon)


func select_tool(i: int, tool_desc: String) -> void:
	tool_btns[i].button_pressed = true
	cursor_icon.texture = icons[i]
	tool_name_label.text = tool_desc


func select_target(i: int) -> void:
	target_btns[i].button_pressed = true


func set_sound(on: bool) -> void:
	sound_btn.text = "音效：开" if on else "音效：关"


func refresh(dt: float, hp: Array, ko: Array, level: int, frac: float, title: String, combo: int, mouse: Vector2, show_cursor: bool) -> void:
	for i in 2:
		hp_shown[i] = lerpf(hp_shown[i], float(hp[i]), minf(1.0, dt * 10.0))
		hp_bars[i].value = hp_shown[i]
		hp_labels[i].text = "血量 %d" % ceili(hp[i]) if hp[i] > 0.0 else "已倒地！"
		ko_labels[i].text = "被打倒 %d 次" % ko[i]
		var fill := hp_bars[i].get_theme_stylebox("fill") as StyleBoxFlat
		var r: float = hp[i] / 100.0
		if r < 0.3:
			fill.bg_color = Color(0.95, 0.25, 0.2)
		elif r < 0.6:
			fill.bg_color = Color(1.0, 0.75, 0.2)
		else:
			fill.bg_color = Color(0.35, 0.85, 0.35) if i == 0 else Color(0.35, 0.75, 1.0)
	relief_bar.value = lerpf(relief_bar.value, frac, minf(1.0, dt * 8.0))
	relief_label.text = "解气值 Lv.%d %s" % [level, title]
	if combo >= 3:
		combo_label.visible = true
		combo_label.text = "%d 连击!" % combo
		if combo != combo_shown:
			combo_label.scale = Vector2.ONE * 1.35
		combo_label.scale = combo_label.scale.lerp(Vector2.ONE, minf(1.0, dt * 12.0))
	else:
		combo_label.visible = false
	combo_shown = combo
	cursor_icon.visible = show_cursor
	cursor_icon.position = mouse + Vector2(14, 10)


func banner(text: String, color: Color) -> void:
	banner_label.text = text
	banner_label.add_theme_color_override("font_color", color)
	if banner_tw:
		banner_tw.kill()
	banner_label.modulate.a = 1.0
	banner_label.pivot_offset = banner_label.size * 0.5
	banner_label.scale = Vector2.ONE * 0.4
	banner_tw = create_tween()
	banner_tw.tween_property(banner_label, "scale", Vector2.ONE, 0.3).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	banner_tw.tween_interval(1.5)
	banner_tw.tween_property(banner_label, "modulate:a", 0.0, 0.5)


func flash(color: Color) -> void:
	flash_rect.color = color
	create_tween().tween_property(flash_rect, "color:a", 0.0, 0.25)


func hide_hint() -> void:
	if hint.visible and hint.modulate.a >= 1.0:
		var tw := create_tween()
		tw.tween_property(hint, "modulate:a", 0.0, 1.5)
		tw.tween_callback(func(): hint.visible = false)
