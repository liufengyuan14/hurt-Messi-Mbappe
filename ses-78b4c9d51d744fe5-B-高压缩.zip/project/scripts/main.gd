extends Node3D
## 暴打神龟呦西 — game controller: input, tool attacks, gang-up, scoring, audio, camera.

const TOOLS := [
	{"id": "glove", "name": "拳套", "desc": "拳击手套：一拳一个包", "cd": 0.2, "color": Color(1, 0.35, 0.3)},
	{"id": "slipper", "name": "拖鞋", "desc": "人字拖：大嘴巴子啪啪啪", "cd": 0.15, "color": Color(0.4, 0.75, 1.0)},
	{"id": "pan", "name": "平底锅", "desc": "平底锅：一锅敲晕，头上起包", "cd": 0.34, "color": Color(1, 0.85, 0.3)},
	{"id": "bat", "name": "球棒", "desc": "棒球棍：直接打飞", "cd": 0.5, "color": Color(1, 0.6, 0.2)},
	{"id": "hammer", "name": "大锤", "desc": "大铁锤：一锤拍扁", "cd": 0.8, "color": Color(1, 0.3, 0.6)},
	{"id": "ball", "name": "足球", "desc": "足球：大力抽射，专打脸", "cd": 0.3, "color": Color(0.9, 0.95, 1.0)},
	{"id": "egg", "name": "臭鸡蛋", "desc": "臭鸡蛋：糊一脸蛋黄", "cd": 0.22, "color": Color(1, 0.9, 0.3)},
	{"id": "firecracker", "name": "鞭炮", "desc": "鞭炮：挂身上噼里啪啦，最后一炸变爆炸头", "cd": 1.0, "color": Color(1, 0.4, 0.2)},
]
const WORDS := {
	"glove": ["砰！", "嘭！", "POW!"], "slipper": ["啪！", "啪叽！", "啪啪！"], "pan": ["铛！！", "咣！"],
	"bat": ["梆！", "飞吧！", "全垒打！"], "hammer": ["咚！！", "扁了！"], "ball": ["咚！", "射门！", "爆射！"],
	"egg": ["啪叽~", "好臭！"], "firecracker": ["噼啪！", "嘭！"],
}
const LEVELS := [0, 120, 350, 700, 1200, 2000, 3200, 5000, 8000]
const TITLES := ["还没解气", "有点意思", "渐入佳境", "爽！", "太爽了！", "通体舒畅", "解气大师", "发泄之神", "宇宙无敌解气王"]
const NAMES := ["神龟", "呦西"]
const SHIRTS := [Color(0.85, 0.15, 0.18), Color(0.15, 0.55, 0.3), Color(0.98, 0.78, 0.15), Color(0.95, 0.45, 0.1),
	Color(0.55, 0.25, 0.7), Color(0.1, 0.1, 0.12), Color(0.2, 0.35, 0.8), Color(0.9, 0.4, 0.6)]
const SKINS := [Color(0.96, 0.8, 0.62), Color(0.87, 0.67, 0.48), Color(0.62, 0.43, 0.29), Color(0.98, 0.86, 0.72)]

var font: Font
var kit: Node3D
var kit_nodes := {}
var cam: Camera3D
var fx: Fx
var hud: Hud
var dummies: Array[Dummy] = []
var fans: Array = []
var sounds := {}
var players: Array[AudioStreamPlayer] = []
var crowd_player: AudioStreamPlayer
var crowd_mat: ShaderMaterial
var sound_on := true

var tool_i := 0
var target_i := 2
var mouse_down := false
var mouse_pos := Vector2.ZERO
var pending_click := false
var cooldown := 0.0
var shake := 0.0
var total := 0.0
var level := 0
var combo := 0
var combo_t := 0.0
var excite := 0.2
var recent := 0.0
var cam_focus := Vector3(0, 0.9, -0.2)
var cam_pos := Vector3(0, 2.0, 4.8)
var hitstop := 0.0
var firecrackers := 0
var clicked_once := false
var mouse_seen := false


func _ready() -> void:
	randomize()
	font = load("res://assets/font.otf")
	kit = (load("res://assets/kit.glb") as PackedScene).instantiate() as Node3D
	for n in ["glove", "slipper", "pan", "bat", "hammer", "ball", "egg", "firecracker", "star", "goal", "spectator", "fan"]:
		var node := kit.find_child(n, true, false) as Node3D
		if node:
			kit_nodes[n] = node
	var w := World.build(self, kit_nodes)
	crowd_mat = w.get("crowd_mat")

	cam = Camera3D.new()
	cam.fov = 50.0
	add_child(cam)
	cam.global_position = cam_pos
	cam.look_at(cam_focus)

	fx = Fx.new()
	fx.main = self
	add_child(fx)
	fx.setup(font)

	var star_mesh: Mesh = (kit_nodes["star"] as MeshInstance3D).mesh
	_spawn_dummy("res://assets/turtle.glb", "神龟", Vector3(-1.1, 0, 0), 0.4,
		["就这？", "打不着我~", "我可是神龟！", "力气太小啦", "挠痒痒呢？", "神龟无敌！", "龟壳硬着呢！"],
		["哎哟！", "疼疼疼！", "别打脸！", "嗷——", "我的壳！", "救命啊！", "轻点！"],
		["我…我还会回来的…", "眼冒金星…", "神龟…倒下了…"],
		["神龟满血复活！", "再来啊！", "神龟不死！"], star_mesh)
	_spawn_dummy("res://assets/mouse.glb", "呦西", Vector3(1.1, 0, 0), 0.24,
		["呦西呦西~", "来抓我呀~", "我可是呦西！", "你打不过我的", "吱吱~就这？", "看我过人！"],
		["吱——！", "哎呀！", "我的胡子！", "痛痛痛！", "别打了！", "吱吱吱！", "我的尾巴！"],
		["吱…不行了…", "呦西…去也…", "我要回家找妈妈…"],
		["呦西复活！", "吱！再来！", "我又行了！"], star_mesh)

	_load_sfx()
	for i in 16:
		var p := AudioStreamPlayer.new()
		add_child(p)
		players.append(p)
	crowd_player = AudioStreamPlayer.new()
	add_child(crowd_player)
	if sounds.has("crowd"):
		crowd_player.stream = sounds["crowd"]
		crowd_player.volume_db = -16.0
		crowd_player.play()

	hud = Hud.new()
	add_child(hud)
	hud.build(font, load("res://assets/icons.png"), TOOLS, NAMES)
	hud.tool_selected.connect(_select_tool)
	hud.target_selected.connect(_select_target)
	hud.gang_pressed.connect(_gang_up)
	hud.heal_pressed.connect(_heal_all)
	hud.sound_toggled.connect(_toggle_sound)
	_select_tool(0)
	_select_target(2)
	hud.banner("开揍！", Color(1, 0.85, 0.2))
	var args := OS.get_cmdline_user_args()
	if args.size() >= 2 and args[0] == "--autotest":
		var at: Node = (load(args[1]) as Script).new()
		add_child(at)


func _exit_tree() -> void:
	if is_instance_valid(kit):
		kit.free()


func _spawn_dummy(path: String, dname: String, home: Vector3, lift: float, taunts: Array, ouches: Array,
		kos: Array, revives: Array, star_mesh: Mesh) -> void:
	var d := Dummy.new()
	add_child(d)
	d.setup(load(path), star_mesh, font)
	d.display_name = dname
	d.home = home
	d.position = home
	d.lie_lift = lift
	d.taunts = taunts
	d.ouches = ouches
	d.ko_lines = kos
	d.revive_lines = revives
	d.main = self
	d.taunt_cd = randf_range(1.5, 4.0)
	d.damaged.connect(_on_damaged)
	d.knocked_out.connect(_on_ko)
	dummies.append(d)


# ------------------------------------------------------------------ audio
func _load_sfx() -> void:
	var bytes := FileAccess.get_file_as_bytes("res://assets/sfx.bin")
	if bytes.size() < 4:
		return
	var count := bytes.decode_u32(0)
	var base := 4 + count * 28
	for i in count:
		var o := 4 + i * 28
		var raw := bytes.slice(o, o + 16)
		var end := raw.find(0)
		var sname := raw.slice(0, end if end >= 0 else 16).get_string_from_ascii()
		var off := bytes.decode_u32(o + 16)
		var frames := bytes.decode_u32(o + 20)
		var loop := bytes.decode_u32(o + 24)
		var w := AudioStreamWAV.new()
		w.format = AudioStreamWAV.FORMAT_16_BITS
		w.mix_rate = 22050
		w.stereo = false
		w.data = bytes.slice(base + off, base + off + frames * 2)
		if loop == 1:
			w.loop_mode = AudioStreamWAV.LOOP_FORWARD
			w.loop_begin = 0
			w.loop_end = frames
		sounds[sname] = w


func sfx(sname: String, vol := 0.0, pitch := 1.0) -> void:
	if not sound_on or not sounds.has(sname):
		return
	var best: AudioStreamPlayer = null
	for p in players:
		if not p.playing:
			best = p
			break
	if best == null:
		best = players[randi() % players.size()]
	best.stream = sounds[sname]
	best.volume_db = vol
	best.pitch_scale = pitch
	best.play()


func _toggle_sound() -> void:
	sound_on = not sound_on
	AudioServer.set_bus_mute(0, not sound_on)
	if sound_on:
		sfx("click", -6.0)
	hud.set_sound(sound_on)


# ------------------------------------------------------------------ UI actions
func _select_tool(i: int) -> void:
	tool_i = i
	hud.select_tool(i, TOOLS[i]["desc"])
	sfx("click", -8.0, 1.0 + i * 0.04)


func _select_target(i: int) -> void:
	target_i = i
	hud.select_target(i)
	sfx("click", -8.0, 0.9)


func _targets() -> Array[Dummy]:
	var out: Array[Dummy] = []
	if target_i == 2:
		out.append_array(dummies)
	else:
		out.append(dummies[target_i])
	return out


func _gang_up() -> void:
	if not kit_nodes.has("fan"):
		return
	var tg := _targets()
	var alive := 0
	for f in fans:
		if is_instance_valid(f):
			alive += 1
	var per := 6 if tg.size() == 1 else 4
	if alive > 14:
		per = 2
	sfx("whistle", -2.0)
	sfx("cheer", -4.0)
	excite = 1.0
	var who: String = "神龟和呦西" if tg.size() == 2 else tg[0].display_name
	hud.banner("兄弟们，围攻%s！" % who, Color(1, 0.45, 0.3))
	for d in tg:
		for k in per:
			var f := Fan.new()
			f.main = self
			add_child(f)
			var ang := deg_to_rad(lerpf(80.0, 280.0, (k + 0.5) / per) + randf_range(-8, 8))
			var side := 1.0 if sin(ang) > 0.0 else -1.0
			var start := Vector3(side * randf_range(7.5, 9.0), 0, randf_range(-5.0, -1.0))
			f.setup(kit_nodes["fan"], d, ang, start, SHIRTS.pick_random(), SKINS.pick_random())
			f.speed = randf_range(3.0, 4.2)
			fans.append(f)
	if randf() < 0.7:
		tg[0].say("你们…你们要干嘛？！", 1.8)


func _heal_all() -> void:
	for d in dummies:
		d.heal()
	for f in fans:
		if is_instance_valid(f):
			f.leave()
	sfx("tink", -4.0, 0.8)
	hud.banner("全体满血复活！继续揍！", Color(0.5, 1, 0.6))
	for d in dummies:
		fx.burst(d.global_position + Vector3(0, 0.8, 0), Fx.Cell.PLUS, 14, Color(0.4, 1, 0.5), 2.0, 0.18, 1.5, 1.0)


# ------------------------------------------------------------------ input
func _unhandled_input(e: InputEvent) -> void:
	if e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT:
		if e.pressed:
			mouse_down = true
			mouse_pos = e.position
			pending_click = true
	elif e is InputEventKey and e.pressed and not e.echo:
		var k: int = e.keycode
		if k >= KEY_1 and k <= KEY_8:
			_select_tool(k - KEY_1)
		elif k == KEY_SPACE:
			_gang_up()
		elif k == KEY_TAB:
			_select_target((target_i + 1) % 3)
		elif k == KEY_H:
			_heal_all()


func _input(e: InputEvent) -> void:
	if e is InputEventMouseMotion:
		mouse_pos = e.position
		mouse_seen = true
	elif e is InputEventScreenTouch:
		mouse_seen = false
	elif e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT and not e.pressed:
		mouse_down = false


func _physics_process(_dt: float) -> void:
	if (pending_click or mouse_down) and cooldown <= 0.0:
		pending_click = false
		_attack_at(mouse_pos)
	pending_click = false


func _pick(screen: Vector2) -> Dictionary:
	var from := cam.project_ray_origin(screen)
	var dir := cam.project_ray_normal(screen)
	var q := PhysicsRayQueryParameters3D.create(from, from + dir * 60.0, 2)
	var r := get_world_3d().direct_space_state.intersect_ray(q)
	if r.is_empty():
		return {}
	var col: Object = r["collider"]
	if not col.has_meta("dummy"):
		return {}
	return _make_hit(col.get_meta("dummy"), col.get_meta("part"), r["position"], r["normal"])


func _make_hit(d: Dummy, part: String, pos: Vector3, normal: Vector3) -> Dictionary:
	var node := d.j[part] as Node3D
	var inv := node.global_transform.affine_inverse()
	return {"dummy": d, "part": part, "node": node, "lpos": inv * pos,
		"lnormal": (node.global_basis.inverse() * normal).normalized(), "pos": pos, "normal": normal}


## Picks a visible surface point on a body part of d (used when clicking empty space).
func _auto_hit(d: Dummy, prefer := "") -> Dictionary:
	var part := prefer
	if part == "":
		var r := randf()
		part = "head" if r < 0.38 else ("torso" if r < 0.82 else ["arm_l", "arm_r", "leg_l", "leg_r", "hips"].pick_random())
	var c := d.part_center(part) + Vector3(randf_range(-0.06, 0.06), randf_range(-0.06, 0.06), 0)
	var from := cam.global_position
	var q := PhysicsRayQueryParameters3D.create(from, from + (c - from) * 1.6, 2)
	var space := get_world_3d().direct_space_state
	var excl: Array[RID] = []
	for i in 6:
		q.exclude = excl
		var r := space.intersect_ray(q)
		if r.is_empty():
			break
		var col: Object = r["collider"]
		if col.get_meta("dummy") == d:
			return _make_hit(d, col.get_meta("part"), r["position"], r["normal"])
		excl.append(r["rid"])
	return _make_hit(d, part, c, (from - c).normalized())


func _attack_at(screen: Vector2) -> void:
	var t: Dictionary = TOOLS[tool_i]
	if not clicked_once:
		clicked_once = true
		hud.hide_hint()
	var hits: Array = []
	var h := _pick(screen)
	if not h.is_empty():
		hits.append(h)
	else:
		for d in _targets():
			hits.append(_auto_hit(d, "head" if t["id"] == "hammer" and not d.is_down() else ""))
	if t["id"] == "firecracker":
		if firecrackers >= 4:
			return
	cooldown = t["cd"]
	for hh in hits:
		_use_tool(t["id"], hh)


# ------------------------------------------------------------------ tools
func _tool_mesh(id: String) -> Node3D:
	return (kit_nodes[id] as Node3D).duplicate() as Node3D


func _swing_dir(h: Dictionary) -> Vector3:
	var d := (h["pos"] as Vector3) - cam.global_position
	d.y *= 0.3
	return d.normalized()


## Animates a held tool swinging into the hit point, then calls `on_hit`.
func _swing(id: String, h: Dictionary, on_hit: Callable, wind := 0.12, strike := 0.08) -> void:
	var tool := _tool_mesh(id)
	add_child(tool)
	var p: Vector3 = h["pos"]
	var n: Vector3 = h["normal"]
	var side := cam.global_basis.x
	var up := Vector3.UP
	var face := (n + (cam.global_position - p).normalized()).normalized()
	var start := p + face * 0.9 + side * 0.55 + up * 0.6
	var mid := p + face * 0.35
	tool.global_position = start
	match id:
		"glove":
			tool.look_at_from_position(start, p, Vector3.UP)
			tool.rotate_object_local(Vector3.UP, PI)
		"pan", "bat":
			tool.look_at_from_position(start, p, Vector3.UP)
			tool.rotate_object_local(Vector3.RIGHT, -PI / 2)
		"slipper":
			tool.look_at_from_position(start, p, Vector3.UP)
			tool.rotate_object_local(Vector3.RIGHT, -PI / 2)
		"hammer":
			start = p + face * 0.7 + up * 1.6 + side * 0.2
			tool.global_position = start
			tool.look_at_from_position(start, p, Vector3.UP)
			tool.rotate_object_local(Vector3.RIGHT, -PI / 2)
			wind = 0.18
			strike = 0.1
	tool.scale = Vector3.ONE * (1.6 if id == "glove" else 1.25)
	var tw := create_tween()
	tw.tween_property(tool, "global_position", start + (start - p).normalized() * 0.25, wind).set_ease(Tween.EASE_OUT)
	tw.tween_property(tool, "global_position", mid.lerp(p, 0.7), strike).set_ease(Tween.EASE_IN)
	tw.tween_callback(on_hit)
	tw.tween_property(tool, "global_position", mid + face * 0.3, 0.12)
	tw.tween_property(tool, "scale", Vector3.ONE * 0.01, 0.12)
	tw.tween_callback(tool.queue_free)
	sfx("whoosh", -9.0, randf_range(0.9, 1.3))


func _use_tool(id: String, h: Dictionary) -> void:
	var d: Dummy = h["dummy"]
	var dir := _swing_dir(h)
	var col: Color = TOOLS[tool_i]["color"]
	match id:
		"glove":
			_swing(id, h, func():
				var dmg := d.hit(h["pos"], dir, 3.2, randf_range(5, 8), h["part"])
				sfx("punch", 0.0, randf_range(0.85, 1.15))
				fx.spark(h["pos"], col, 10)
				_word(h, col)
				if h["part"] == "head" and randf() < 0.45:
					_tooth(h)
				if randf() < 0.55:
					fx.patch(h["node"], h["lpos"], h["lnormal"], Fx.Patch.BRUISE, randf_range(0.13, 0.2), d)
				_score(dmg, 1.0)
				_shake(0.08))
		"slipper":
			_swing(id, h, func():
				var dmg := d.hit(h["pos"], dir, 2.0, randf_range(3, 5), h["part"])
				sfx("slap", 0.0, randf_range(0.9, 1.25))
				fx.burst(h["pos"], Fx.Cell.STAR, 5, Color(1, 0.6, 0.6), 2.5, 0.1, -3.0, 0.35)
				_word(h, col)
				fx.patch(h["node"], h["lpos"], h["lnormal"], Fx.Patch.SLAP if randf() < 0.6 else Fx.Patch.SLIPPER, randf_range(0.13, 0.18), d)
				_score(dmg, 0.8)
				_shake(0.04), 0.08, 0.06)
		"pan":
			_swing(id, h, func():
				var on_head: bool = h["part"] == "head"
				var dmg := d.hit(h["pos"], dir, 3.8, randf_range(8, 12) * (1.3 if on_head else 1.0), h["part"], {"dizzy": 2.6 if on_head else 0.8})
				sfx("clang", 0.0, randf_range(0.92, 1.08))
				if on_head:
					sfx("dizzy", -6.0)
					d.add_bump(h["pos"])
				fx.spark(h["pos"], Color(1, 1, 0.7), 16, 1.3)
				_word(h, col, 1.2)
				hud.flash(Color(1, 1, 0.8, 0.15))
				_score(dmg, 1.3)
				_shake(0.15)
				hitstop = 0.05)
		"bat":
			_swing(id, h, func():
				var dmg := d.hit(h["pos"], _away(dir) + Vector3.UP * 0.3, 7.5, randf_range(12, 17), h["part"], {"knock": true})
				sfx("crack", 0.0, randf_range(0.9, 1.1))
				fx.spark(h["pos"], col, 18, 1.4)
				_word(h, col, 1.25)
				fx.patch(h["node"], h["lpos"], h["lnormal"], Fx.Patch.BRUISE, 0.22, d)
				hud.flash(Color(1, 0.9, 0.7, 0.2))
				_score(dmg, 1.5)
				_shake(0.25)
				hitstop = 0.07)
		"hammer":
			_swing(id, h, func():
				var dmg := d.hit(h["pos"], Vector3.DOWN + dir * 0.3, 4.0, randf_range(18, 25), h["part"], {"squash": not d.is_down(), "dizzy": 3.0})
				sfx("boom", 0.0, randf_range(0.9, 1.05))
				fx.dust(Vector3(d.global_position.x, 0.05, d.global_position.z), 16, 1.5)
				fx.burst(h["pos"], Fx.Cell.STAR, 22, col, 4.5, 0.16, -5.0, 0.6)
				_word(h, col, 1.4)
				hud.flash(Color(1, 1, 1, 0.3))
				_score(dmg, 1.8)
				_shake(0.45)
				hitstop = 0.1)
		"ball":
			_kick_ball(h)
		"egg":
			_throw_egg(h)
		"firecracker":
			_hang_firecracker(h)


## Pushes a hit direction so knock-backs never fly into the camera.
func _away(dir: Vector3) -> Vector3:
	var d := Vector3(dir.x, 0, minf(dir.z, -0.5))
	return d.normalized()


func _word(h: Dictionary, col: Color, size := 1.0) -> void:
	var list: Array = WORDS.get(TOOLS[tool_i]["id"], ["砰！"])
	fx.word(h["pos"], list.pick_random(), col, size * randf_range(0.9, 1.1))


func _tooth(h: Dictionary) -> void:
	var t := fx.make_bit(Color(1, 1, 0.96), Vector3(0.035, 0.045, 0.025))
	var v := ((h["normal"] as Vector3) * 2.0 + Vector3(randf_range(-1, 1), 3.5, randf_range(-1, 1)))
	fx.throw_debris(t, h["pos"], v, 3.0, "tink")


func _projectile(node: Node3D, from: Vector3, h: Dictionary, time: float, arc: float, on_hit: Callable) -> void:
	add_child(node)
	node.global_position = from
	var to: Vector3 = h["pos"]
	var tw := create_tween()
	tw.tween_method(func(t: float):
		var p := from.lerp(to, t)
		p.y += sin(t * PI) * arc
		if is_instance_valid(node):
			node.global_position = p
			node.rotation += Vector3(0.3, 0.2, 0.1), 0.0, 1.0, time)
	tw.tween_callback(func():
		if is_instance_valid(node):
			node.queue_free()
		on_hit.call())


func _kick_ball(h: Dictionary) -> void:
	var d: Dummy = h["dummy"]
	var ball := _tool_mesh("ball")
	ball.scale = Vector3.ONE * 1.4
	var from := cam.global_position + cam.global_basis * Vector3(randf_range(-0.6, 0.6), -1.1, -0.8)
	sfx("kick", -2.0, randf_range(0.9, 1.1))
	_projectile(ball, from, h, 0.22, 0.15, func():
		var dir := ((h["pos"] as Vector3) - from).normalized()
		var dmg := d.hit(h["pos"], _away(dir), 4.5, randf_range(8, 12), h["part"], {"knock": randf() < 0.25})
		sfx("punch", -2.0, 0.7)
		fx.spark(h["pos"], Color(1, 1, 1), 10)
		_word(h, Color(0.9, 0.95, 1.0))
		fx.patch(h["node"], h["lpos"], h["lnormal"], Fx.Patch.BALL, randf_range(0.16, 0.22), d)
		var rb := _tool_mesh("ball")
		rb.scale = Vector3.ONE * 1.4
		var bounce := (h["normal"] as Vector3) * 3.0 + Vector3(randf_range(-1.5, 1.5), 3.0, 1.0)
		fx.throw_debris(rb, h["pos"], bounce, 3.5, "bounce")
		_score(dmg, 1.2)
		_shake(0.12))


func _throw_egg(h: Dictionary) -> void:
	var d: Dummy = h["dummy"]
	var egg := _tool_mesh("egg")
	egg.scale = Vector3.ONE * 1.5
	var from := cam.global_position + cam.global_basis * Vector3(randf_range(-0.5, 0.5), -0.6, -0.6)
	sfx("whoosh", -8.0, 1.4)
	_projectile(egg, from, h, 0.35, 0.5, func():
		var dmg := d.hit(h["pos"], ((h["pos"] as Vector3) - from).normalized(), 1.5, randf_range(2, 4), h["part"])
		sfx("splat", 0.0, randf_range(0.85, 1.15))
		fx.burst(h["pos"], Fx.Cell.DOT, 14, Color(1, 0.88, 0.2, 0.95), 2.5, 0.07, -9.0, 0.6)
		fx.burst(h["pos"], Fx.Cell.DOT, 8, Color(1, 1, 0.92, 0.95), 2.0, 0.06, -9.0, 0.5)
		fx.burst(h["pos"] + Vector3(0, 0.15, 0), Fx.Cell.PUFF, 5, Color(0.55, 0.7, 0.25, 0.5), 0.8, 0.35, 0.8, 1.4, 40.0)
		_word(h, Color(1, 0.9, 0.3))
		fx.patch(h["node"], h["lpos"], h["lnormal"], Fx.Patch.EGG, randf_range(0.2, 0.28), d)
		if randf() < 0.3:
			d.say(["好臭啊！", "呕——", "这蛋放了多久？！"].pick_random(), 1.3)
		for i in 3:
			var shell := fx.make_bit(Color(0.92, 0.88, 0.75), Vector3(0.04, 0.008, 0.03))
			fx.throw_debris(shell, h["pos"], Vector3(randf_range(-1.5, 1.5), randf_range(0.5, 2.0), randf_range(0.5, 1.5)), 2.5)
		_score(dmg, 1.0))


func _hang_firecracker(h: Dictionary) -> void:
	var d: Dummy = h["dummy"]
	var fc := _tool_mesh("firecracker")
	var torso := d.j["torso"] as Node3D
	torso.add_child(fc)
	var tc: Vector3 = d.part_center("torso")
	var front := (cam.global_position - tc)
	front.y = 0
	front = front.normalized()
	var top := tc + Vector3.UP * 0.32 + front * (0.36 if d.display_name == "神龟" else 0.3) + Vector3(randf_range(-0.12, 0.12), 0, 0)
	fc.global_position = top
	fc.global_basis = Basis.IDENTITY.scaled(Vector3.ONE * 1.1)
	firecrackers += 1
	d.panic = 4.2
	d.say(["别别别！！", "不要啊！！", "快拿走！！"].pick_random(), 1.5)
	sfx("fuse", -6.0)
	var crackers: Array = []
	for c in fc.get_children():
		if c.name.begins_with("fc_"):
			crackers.append(c)
	crackers.reverse()
	var tw := create_tween()
	tw.tween_interval(0.75)
	for c in crackers:
		tw.tween_callback(func():
			if not is_instance_valid(c):
				return
			var p: Vector3 = (c as Node3D).global_position
			(c as Node3D).visible = false
			sfx("pop", -3.0, randf_range(0.8, 1.3))
			fx.burst(p, Fx.Cell.STAR, 6, Color(1, 0.75, 0.2), 3.0, 0.08, -3.0, 0.3)
			fx.smoke(p, 2, 0.6)
			var dd := d.hit(p, Vector3(randf_range(-1, 1), 0.4, randf_range(-1, 1)).normalized(), 1.6, randf_range(1.5, 2.5), "torso")
			_score(dd, 0.6)
			var paper := fx.make_bit(Color(0.9, 0.15, 0.15), Vector3(0.04, 0.003, 0.03))
			fx.throw_debris(paper, p, Vector3(randf_range(-2, 2), randf_range(1, 3), randf_range(-2, 2)), 2.5)
			_shake(0.05))
		tw.tween_interval(randf_range(0.18, 0.28))
	tw.tween_callback(func():
		var p: Vector3 = d.part_center("torso")
		sfx("bang", 0.0)
		fx.burst(p, Fx.Cell.PUFF, 18, Color(1, 0.6, 0.2, 0.9), 3.5, 0.6, 0.5, 0.7)
		fx.smoke(p + Vector3(0, 0.3, 0), 14, 1.6)
		fx.burst(p, Fx.Cell.STAR, 24, Color(1, 0.85, 0.3), 5.0, 0.15, -4.0, 0.6)
		var dd := d.hit(p, Vector3(randf_range(-0.4, 0.4), 1, -0.7).normalized(), 7.0, randf_range(12, 16), "torso", {"knock": true, "dizzy": 3.0})
		_score(dd, 2.0)
		d.set_afro(true)
		for k in 3:
			var part: String = ["torso", "head", "hips"][k]
			var hh := _auto_hit(d, part)
			fx.patch(hh["node"], hh["lpos"], hh["lnormal"], Fx.Patch.SOOT, randf_range(0.2, 0.3), d)
		hud.flash(Color(1, 0.7, 0.3, 0.35))
		fx.word(p + Vector3(0, 0.4, 0), "轰！！！", Color(1, 0.45, 0.15), 1.6)
		_shake(0.5)
		hitstop = 0.08
		firecrackers -= 1
		if is_instance_valid(fc):
			fc.queue_free())


## Called by Fan when its punch/kick lands.
func fan_strike(f: Fan, d: Dummy, kind: int) -> void:
	var part := "torso"
	if kind == 0 and not d.is_down():
		part = "head" if randf() < 0.5 else "torso"
	elif kind == 1:
		part = "leg_l" if randf() < 0.5 else "hips"
	var h := _auto_hit(d, part)
	var dir := ((h["pos"] as Vector3) - f.global_position)
	dir.y = 0.2
	dir = dir.normalized()
	var dmg := d.hit(h["pos"], dir, 2.4, randf_range(2.5, 4.5), h["part"])
	sfx("punch" if kind != 2 else "kick", -7.0, randf_range(0.8, 1.3))
	fx.burst(h["pos"], Fx.Cell.STAR, 4, Color(1, 0.9, 0.5), 2.0, 0.07, -3.0, 0.3)
	if randf() < 0.25:
		fx.word(h["pos"], ["砰！", "揍！", "嘭！", "啪！"].pick_random(), Color(1, 0.8, 0.4), 0.7)
	if randf() < 0.18:
		fx.patch(h["node"], h["lpos"], h["lnormal"], Fx.Patch.BRUISE if randf() < 0.6 else Fx.Patch.DIRT, randf_range(0.11, 0.16), d)
	_score(dmg, 0.35)


# ------------------------------------------------------------------ feedback
func _on_damaged(d: Dummy, amount: float, crit: bool, pos: Vector3) -> void:
	if amount >= 3.0 and d.ow_ok():
		sfx("ow_turtle" if d.display_name == "神龟" else "ow_mouse", -5.0, randf_range(0.9, 1.15))
	if amount >= 1.0:
		fx.number(pos, amount, crit)
	if crit:
		fx.word(pos + Vector3(0, 0.3, 0), "暴击！", Color(1, 0.85, 0.1), 1.2)


func _on_ko(d: Dummy) -> void:
	sfx("ko", -2.0)
	sfx("cheer", -3.0)
	excite = 1.0
	hud.banner("%s 被打趴了！K.O.！" % d.display_name, Color(1, 0.4, 0.3))
	hud.flash(Color(1, 1, 1, 0.4))
	_score(30.0, 3.0)


func on_land(d: Dummy) -> void:
	sfx("boom", -6.0, 1.5)
	fx.dust(d.global_position + Vector3(0, 0, -0.5), 14, 1.2)
	fx.ground_patch(d.global_position + Vector3(0, 0, -0.5), Fx.Patch.DIRT, 0.9)
	_shake(0.15)


func dust(pos: Vector3, n: int) -> void:
	fx.dust(pos, n)


func auto_revive(d: Dummy) -> void:
	d.revive()
	sfx("tink", -6.0, 0.7)
	fx.burst(d.global_position + Vector3(0, 0.6, 0), Fx.Cell.PLUS, 10, Color(0.4, 1, 0.5), 2.0, 0.16, 1.5, 1.0)


func _score(dmg: float, weight: float) -> void:
	if dmg <= 0.0:
		return
	combo += 1
	combo_t = 1.4
	var gain := dmg * weight * (1.0 + minf(combo, 50) * 0.04)
	total += gain
	recent += gain
	while level < LEVELS.size() - 1 and total >= LEVELS[level + 1]:
		level += 1
		sfx("cheer", -5.0, 1.1)
		hud.banner("解气值升级！Lv.%d %s" % [level, TITLES[level]], Color(1, 0.8, 0.25))
	excite = minf(1.0, excite + 0.03 * weight)


func _shake(a: float) -> void:
	shake = maxf(shake, a)


# ------------------------------------------------------------------ frame
func _process(dt: float) -> void:
	if hitstop > 0.0:
		hitstop -= dt
		Engine.time_scale = 0.25
	else:
		Engine.time_scale = 1.0
	cooldown -= dt
	combo_t -= dt
	if combo_t <= 0.0:
		combo = 0
	recent = maxf(0.0, recent - dt * 30.0)
	excite = lerpf(excite, 0.2 + minf(0.6, recent / 120.0), minf(1.0, dt * 0.8))
	if crowd_mat:
		crowd_mat.set_shader_parameter("excite", excite)
	if crowd_player:
		crowd_player.volume_db = lerpf(-20.0, -7.0, excite)
	fans = fans.filter(func(f): return is_instance_valid(f))

	# camera: frame selected targets
	var tg := _targets()
	var c := Vector3.ZERO
	for d in tg:
		c += d.global_position
	c /= tg.size()
	var focus := Vector3(c.x * 0.85, 0.75, c.z - 0.1)
	var dist := 4.6 if tg.size() == 2 else 3.3
	if tg.size() == 2:
		var spread := tg[0].global_position.distance_to(tg[1].global_position)
		dist += maxf(0.0, spread - 2.2) * 0.9
		focus.z = minf(focus.z, maxf(tg[0].global_position.z, tg[1].global_position.z) - 0.4)
	var want := focus + Vector3(0, 1.15 + (0.7 if fans.size() > 0 else 0.0), dist + (0.6 if fans.size() > 0 else 0.0))
	var aspect := get_viewport().get_visible_rect().size.aspect()
	if aspect < 1.0:
		want.z += (1.0 / aspect - 1.0) * 2.4
	cam_focus = cam_focus.lerp(focus, minf(1.0, dt * 3.0))
	cam_pos = cam_pos.lerp(want, minf(1.0, dt * 3.0))
	var off := Vector3.ZERO
	if shake > 0.0:
		off = Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)) * shake * 0.18
		shake = maxf(0.0, shake - dt * 2.2)
	cam.global_position = cam_pos + off
	cam.look_at(cam_focus + off * 0.5)

	var hp := [dummies[0].hp, dummies[1].hp]
	var ko := [dummies[0].ko_count, dummies[1].ko_count]
	var lo: float = LEVELS[level]
	var hi: float = LEVELS[mini(level + 1, LEVELS.size() - 1)]
	var frac := 1.0 if hi <= lo else (total - lo) / (hi - lo)
	var over_ui := get_viewport().gui_get_hovered_control() != null
	hud.refresh(dt, hp, ko, level, frac, TITLES[level], combo, mouse_pos, mouse_seen and not over_ui)
