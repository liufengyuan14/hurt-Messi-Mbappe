class_name Fan
extends Node3D
## A helper fan that runs in, surrounds a target and beats it up, then leaves.

var main
var target: Dummy
var angle := 0.0
var parts := {}
var state := 0  # 0 run in, 1 attack, 2 leave
var life := 14.0
var atk_cd := 0.5
var atk_t := -1.0
var atk_kind := 0
var struck := false
var clock := 0.0
var exit_pos := Vector3.ZERO
var speed := 3.4


func setup(tmpl: Node3D, tgt: Dummy, ang: float, start: Vector3, shirt: Color, skin: Color) -> void:
	var m := tmpl.duplicate() as Node3D
	add_child(m)
	m.position = Vector3.ZERO
	for n in ["body", "head", "arm_l", "arm_r", "leg_l", "leg_r"]:
		parts[n] = m.find_child(n, true, false)
	var shirt_mat := StandardMaterial3D.new()
	shirt_mat.albedo_color = shirt
	shirt_mat.roughness = 0.7
	var skin_mat := StandardMaterial3D.new()
	skin_mat.albedo_color = skin
	skin_mat.roughness = 0.6
	for n in parts:
		var mi := parts[n] as MeshInstance3D
		if mi == null:
			continue
		for i in mi.mesh.get_surface_count():
			var mat := mi.mesh.surface_get_material(i)
			if mat == null:
				continue
			if mat.resource_name.begins_with("fan_shirt"):
				mi.set_surface_override_material(i, shirt_mat)
			elif mat.resource_name.begins_with("fan_skin"):
				mi.set_surface_override_material(i, skin_mat)
	position = start
	exit_pos = start
	target = tgt
	angle = ang
	scale = Vector3.ONE * randf_range(1.0, 1.15)
	life = randf_range(12.0, 16.0)
	atk_cd = randf_range(0.2, 0.9)


func leave() -> void:
	if state != 2:
		state = 2
		life = 0.0


func _rot(n: String, v: Vector3) -> void:
	var node := parts.get(n) as Node3D
	if node:
		node.rotation = v


func _process(delta: float) -> void:
	var dt := minf(delta, 0.05)
	clock += dt
	life -= dt
	if not is_instance_valid(target):
		leave()
	if life <= 0.0 and state != 2:
		leave()
	var walking := false
	if state == 2:
		var to := exit_pos - position
		to.y = 0.0
		if to.length() < 0.3:
			queue_free()
			return
		position += to.normalized() * speed * 1.2 * dt
		rotation.y = lerp_angle(rotation.y, atan2(to.x, to.z), dt * 10.0)
		walking = true
	else:
		var tp := target.global_position
		tp.y = 0.0
		var r := 0.85 if not target.is_down() else 1.0
		var goal := tp + Vector3(sin(angle), 0, cos(angle)) * r
		goal.z = minf(goal.z, tp.z + 0.3)
		if target.is_down():
			# when lying, crowd around the body (it extends behind the feet)
			goal += Vector3(0, 0, -0.6).rotated(Vector3.UP, target.pivot.rotation.y)
		var to := goal - position
		to.y = 0.0
		if to.length() > 0.2:
			position += to.normalized() * minf(speed * dt, to.length())
			walking = true
			if state == 1 and to.length() > 0.6:
				state = 0
		else:
			state = 1
		var look := tp - position
		if target.is_down():
			look = target.part_center("torso") - position
		look.y = 0.0
		if walking and state == 0:
			rotation.y = lerp_angle(rotation.y, atan2(to.x, to.z), dt * 10.0)
		elif look.length() > 0.01:
			rotation.y = lerp_angle(rotation.y, atan2(look.x, look.z), dt * 10.0)
	if state == 1:
		_attack(dt)
	elif walking:
		var s := sin(clock * 14.0)
		_rot("leg_l", Vector3(-s * 0.7, 0, 0))
		_rot("leg_r", Vector3(s * 0.7, 0, 0))
		_rot("arm_l", Vector3(s * 0.7, 0, 0.1))
		_rot("arm_r", Vector3(-s * 0.7, 0, -0.1))
		_rot("head", Vector3.ZERO)
		var b := parts.get("body") as Node3D
		if b:
			b.position.y = 0.62 + absf(cos(clock * 14.0)) * 0.04


func _attack(dt: float) -> void:
	var b := parts.get("body") as Node3D
	if b:
		b.position.y = 0.62
	if atk_t < 0.0:
		atk_cd -= dt
		# idle bounce while waiting
		_rot("arm_l", Vector3(-1.2, 0, 0.2))
		_rot("arm_r", Vector3(-1.2 + sin(clock * 10.0) * 0.2, 0, -0.2))
		_rot("leg_l", Vector3.ZERO)
		_rot("leg_r", Vector3.ZERO)
		if atk_cd <= 0.0:
			atk_t = 0.0
			struck = false
			atk_kind = 2 if target.is_down() and randf() < 0.6 else (randi() % 3 if not target.is_down() else 0)
			if atk_kind == 2 and not target.is_down():
				atk_kind = 1
		return
	atk_t += dt
	var f := atk_t / 0.38
	var strike := sin(clampf(f, 0.0, 1.0) * PI)
	match atk_kind:
		0, 2:
			var arm := "arm_r" if int(clock * 3.0) % 2 == 0 else "arm_l"
			_rot(arm, Vector3(-0.6 - strike * 1.2, 0, 0))
			_rot("head", Vector3(0.15 * strike, 0, 0))
		1:
			_rot("leg_r", Vector3(-strike * 1.3, 0, 0))
			_rot("arm_l", Vector3(0.5 * strike, 0, 0.5))
			_rot("arm_r", Vector3(0.5 * strike, 0, -0.5))
	if atk_kind == 2:
		_rot("leg_l", Vector3(-strike * 0.9, 0, 0))
	if not struck and f >= 0.45:
		struck = true
		if main and is_instance_valid(target):
			main.fan_strike(self, target, atk_kind)
	if f >= 1.0:
		atk_t = -1.0
		atk_cd = randf_range(0.35, 0.9)
