class_name Dummy
extends Node3D
## A beatable character built from rigid joint nodes (see src_tools/build_assets.py).
## Pose = procedural base pose (state dependent) + per-joint springs driven by hit torques.

signal damaged(dummy: Dummy, amount: float, crit: bool, pos: Vector3)
signal knocked_out(dummy: Dummy)

const JOINTS := ["hips", "torso", "head", "arm_l", "forearm_l", "arm_r", "forearm_r",
	"leg_l", "shin_l", "leg_r", "shin_r", "tail1", "tail2", "tail3"]
const CHAIN := {"hips": "", "torso": "hips", "head": "torso", "arm_l": "torso", "forearm_l": "arm_l",
	"arm_r": "torso", "forearm_r": "arm_r", "leg_l": "hips", "shin_l": "leg_l", "leg_r": "hips",
	"shin_r": "leg_r", "tail1": "hips", "tail2": "tail1", "tail3": "tail2"}
const FACE_NODES := ["eyes_open", "eyes_hurt", "eyes_ko", "eyes_dizzy", "mouth_smile", "mouth_open", "bandage", "afro"]
const BOUNDS := Rect2(-3.3, -4.6, 6.6, 5.4)

enum St { IDLE, STAGGER, AIR, DOWN, KO, GETUP, WALK }

var display_name := ""
var hp := 100.0
var max_hp := 100.0
var home := Vector3.ZERO
var lie_lift := 0.3
var taunts: Array = []
var ouches: Array = []
var ko_lines: Array = []
var revive_lines: Array = []
var main

var pivot: Node3D
var model: Node3D
var j := {}
var spring := {}
var spring_v := {}
var faces := {}
var star_anchor: Node3D
var star_ring: Node3D
var bubble: Label3D
var skin_mat: Material
var patches: Array = []
var bumps: Array = []

var state := St.IDLE
var st_t := 0.0
var vel := Vector3.ZERO
var fall := 0.0
var yaw_spin := 0.0
var squash := 0.0
var squash_v := 0.0
var squash_hold := 0.0
var dizzy := 0.0
var hurt_face := 0.0
var panic := 0.0
var since_hit := 10.0
var taunt_cd := 2.5
var taunt_kind := -1
var taunt_t := 0.0
var blink_t := 2.0
var clock := 0.0
var ko_count := 0
var ko_t := 0.0
var bubble_t := 0.0
var has_firecracker := false


func setup(scene: PackedScene, star_mesh: Mesh, font: Font) -> void:
	pivot = Node3D.new()
	add_child(pivot)
	model = scene.instantiate() as Node3D
	pivot.add_child(model)
	for n in JOINTS:
		var node := model.find_child(n, true, false) as Node3D
		if node:
			j[n] = node
			spring[n] = Vector3.ZERO
			spring_v[n] = Vector3.ZERO
			if node is MeshInstance3D:
				_add_collider(node as MeshInstance3D, n)
	for f in FACE_NODES:
		faces[f] = model.find_child(f, true, false)
	_show("bandage", false)
	_show("afro", false)
	var head := j["head"] as MeshInstance3D
	skin_mat = head.get_active_material(0)
	star_anchor = model.find_child("star_anchor", true, false) as Node3D
	if star_anchor == null:
		star_anchor = Node3D.new()
		head.add_child(star_anchor)
		star_anchor.position = Vector3(0, 0.45, 0)
	star_ring = Node3D.new()
	star_anchor.add_child(star_ring)
	for i in 5:
		var s := MeshInstance3D.new()
		s.mesh = star_mesh
		s.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		var a := TAU * i / 5.0
		s.position = Vector3(cos(a) * 0.24, 0.02 * sin(a * 2.0), sin(a) * 0.24)
		s.scale = Vector3.ONE * 0.9
		star_ring.add_child(s)
	star_ring.visible = false
	bubble = Label3D.new()
	bubble.font = font
	bubble.font_size = 56
	bubble.outline_size = 18
	bubble.pixel_size = 0.0042
	bubble.modulate = Color(1, 1, 1)
	bubble.outline_modulate = Color(0.08, 0.08, 0.12)
	bubble.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	bubble.no_depth_test = true
	bubble.render_priority = 8
	bubble.outline_render_priority = 7
	bubble.visible = false
	bubble.top_level = true
	add_child(bubble)


func _add_collider(mi: MeshInstance3D, part: String) -> void:
	var body := StaticBody3D.new()
	body.collision_layer = 2
	body.collision_mask = 0
	var cs := CollisionShape3D.new()
	cs.shape = mi.mesh.create_trimesh_shape()
	body.add_child(cs)
	mi.add_child(body)
	body.set_meta("dummy", self)
	body.set_meta("part", part)


func _show(n: String, v: bool) -> void:
	var node: Node3D = faces.get(n)
	if node:
		node.visible = v


var ow_cd := 0.0


func ow_ok() -> bool:
	if ow_cd > 0.0:
		return false
	ow_cd = 0.5
	return true


func is_down() -> bool:
	return fall > 0.5


func part_center(part: String) -> Vector3:
	var mi := j.get(part, j["torso"]) as MeshInstance3D
	var c := mi.mesh.get_aabb().get_center()
	if part == "torso":
		c.y += 0.08
	return mi.global_transform * c


func head_top() -> Vector3:
	var mi := j["head"] as MeshInstance3D
	var bb := mi.mesh.get_aabb()
	return mi.global_transform * Vector3(0, bb.end.y - 0.05, bb.get_center().z)


func say(text: String, dur := 1.6) -> void:
	bubble.text = text
	bubble.visible = true
	bubble_t = dur
	bubble.scale = Vector3.ONE * 0.3
	var tw := create_tween()
	tw.tween_property(bubble, "scale", Vector3.ONE, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


## Main entry point for every attack. Returns the damage actually dealt.
func hit(pos: Vector3, dir: Vector3, force: float, dmg: float, part: String, opts := {}) -> float:
	since_hit = 0.0
	taunt_kind = -1
	var crit := false
	if dmg > 0.0 and randf() < 0.12:
		dmg *= 2.0
		crit = true
	var was_ko := state == St.KO or hp <= 0.0
	if not was_ko:
		hp = maxf(0.0, hp - dmg)
	_impulse(pos, dir, force, part)
	hurt_face = 0.55
	var dz: float = opts.get("dizzy", 0.0)
	if dz > 0.0:
		dizzy = maxf(dizzy, dz)
	if opts.get("squash", false):
		squash = 0.72
		squash_v = 0.0
		squash_hold = 0.55
	if not was_ko and randf() < 0.3 and bubble_t < 0.6:
		say(ouches.pick_random(), 1.1)
	damaged.emit(self, dmg, crit, pos)
	if not was_ko and hp <= 0.0:
		ko_count += 1
		ko_t = 0.0
		say(ko_lines.pick_random(), 2.6)
		_launch(dir, maxf(force, 3.5))
		knocked_out.emit(self)
	elif opts.get("knock", false) and state != St.AIR:
		_launch(dir, force)
	elif state == St.IDLE or state == St.WALK or state == St.STAGGER:
		state = St.STAGGER
		st_t = 0.0
	return dmg


func _impulse(pos: Vector3, dir: Vector3, force: float, part: String) -> void:
	var inv := model.global_transform.affine_inverse()
	var lp: Vector3 = inv * pos
	var ld: Vector3 = (inv.basis * dir).normalized() * force
	var n := part if j.has(part) else "torso"
	var gain := 5.0
	while n != "" and j.has(n):
		var jp: Vector3 = inv * (j[n] as Node3D).global_position
		var tq: Vector3 = (lp - jp).cross(ld)
		spring_v[n] += tq * gain
		gain *= 0.5
		n = CHAIN[n]
	for a in ["arm_l", "arm_r", "forearm_l", "forearm_r"]:
		spring_v[a] += Vector3(randf_range(-1, 1), randf_range(-0.4, 0.4), randf_range(-1, 1)) * force * 2.2
	if state == St.IDLE or state == St.STAGGER or state == St.WALK:
		var h := Vector3(dir.x, 0, dir.z)
		if h.length() > 0.01:
			vel += h.normalized() * minf(force, 4.0) * 0.35


func _launch(dir: Vector3, force: float) -> void:
	state = St.AIR
	st_t = 0.0
	var h := Vector3(dir.x, 0, dir.z)
	if h.length() < 0.1:
		h = Vector3(0, 0, -1)
	vel = h.normalized() * clampf(force * 0.55, 1.5, 5.0) + Vector3.UP * clampf(force * 0.6, 2.2, 5.5)
	yaw_spin = randf_range(-7.0, 7.0) if force > 5.0 else 0.0


func add_bump(world_pos: Vector3) -> void:
	var head := j["head"] as Node3D
	var lp: Vector3 = head.global_transform.affine_inverse() * world_pos
	for b in bumps:
		var bn := b as Node3D
		if bn.position.distance_to(lp) < 0.09 or bumps.size() >= 3:
			var s := minf(bn.scale.x + 0.25, 1.7)
			create_tween().tween_property(bn, "scale", Vector3.ONE * s, 0.3).set_trans(Tween.TRANS_ELASTIC).set_ease(Tween.EASE_OUT)
			return
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.05
	sm.height = 0.1
	sm.radial_segments = 16
	sm.rings = 8
	mi.mesh = sm
	mi.material_override = skin_mat
	head.add_child(mi)
	mi.position = lp
	mi.scale = Vector3.ONE * 0.05
	bumps.append(mi)
	create_tween().tween_property(mi, "scale", Vector3.ONE, 0.45).set_trans(Tween.TRANS_ELASTIC).set_ease(Tween.EASE_OUT)


func add_patch(p: Node3D) -> void:
	patches.append(p)
	if patches.size() > 40:
		var old := patches.pop_front() as Node3D
		if is_instance_valid(old):
			old.queue_free()


func set_afro(v: bool) -> void:
	_show("afro", v)


func heal() -> void:
	for p in patches:
		if is_instance_valid(p):
			(p as Node).queue_free()
	patches.clear()
	for b in bumps:
		if is_instance_valid(b):
			(b as Node).queue_free()
	bumps.clear()
	set_afro(false)
	revive()


func revive() -> void:
	hp = max_hp
	ko_t = 0.0
	dizzy = 0.0
	panic = 0.0
	if fall > 0.0:
		state = St.GETUP
	else:
		state = St.IDLE
	st_t = 0.0
	if ko_count > 0:
		_show("bandage", true)
	say(revive_lines.pick_random(), 2.0)


func _process(delta: float) -> void:
	var dt := minf(delta, 0.05)
	clock += dt
	st_t += dt
	since_hit += dt
	hurt_face -= dt
	dizzy -= dt
	panic -= dt
	bubble_t -= dt
	ow_cd -= dt
	if bubble_t <= 0.0:
		bubble.visible = false
	_update_motion(dt)
	_update_taunt(dt)
	var sub := ceili(dt / 0.006)
	for i in sub:
		_update_springs(dt / sub)
		_step_squash(dt / sub)
	_apply_pose(_base_pose())
	_update_face(dt)
	_update_squash(dt)
	star_ring.visible = dizzy > 0.0 or state == St.KO
	if star_ring.visible:
		star_ring.rotation.y += dt * 4.0
	bubble.global_position = star_anchor.global_position + Vector3(0, 0.45, 0)
	if state == St.KO:
		ko_t += dt


func _update_motion(dt: float) -> void:
	var lie := smoothstep(0.0, 1.0, fall)
	match state:
		St.AIR:
			vel.y -= 14.0 * dt
			position += vel * dt
			fall = minf(1.0, fall + dt * 2.4)
			pivot.rotation.y += yaw_spin * dt
			if position.x < BOUNDS.position.x or position.x > BOUNDS.end.x:
				vel.x = -vel.x * 0.5
			if position.z < BOUNDS.position.y or position.z > BOUNDS.end.y:
				vel.z = -vel.z * 0.5
			if position.y <= 0.0 and vel.y < 0.0:
				position.y = 0.0
				if vel.y < -4.0:
					vel = Vector3(vel.x * 0.5, -vel.y * 0.32, vel.z * 0.5)
					if main:
						main.sfx("bounce", -4.0, randf_range(0.6, 0.8))
						main.dust(global_position, 10)
				else:
					vel = Vector3.ZERO
					fall = 1.0
					state = St.KO if hp <= 0.0 else St.DOWN
					st_t = 0.0
					if main:
						main.on_land(self)
		St.DOWN:
			if st_t > 1.3:
				state = St.GETUP
				st_t = 0.0
		St.GETUP:
			fall = maxf(0.0, fall - dt * 1.7)
			if fall <= 0.0:
				state = St.IDLE
				st_t = 0.0
		St.KO:
			if ko_t > 8.0 and main:
				main.auto_revive(self)
		_:
			position += vel * dt
			vel = vel.move_toward(Vector3.ZERO, 6.0 * dt)
			if state == St.STAGGER and st_t > 0.55:
				state = St.IDLE
			var to_home := home - position
			to_home.y = 0.0
			if state == St.IDLE and to_home.length() > 0.5 and since_hit > 1.2:
				state = St.WALK
			if state == St.WALK:
				if to_home.length() < 0.06:
					state = St.IDLE
				else:
					position += to_home.normalized() * minf(1.5 * dt, to_home.length())
					var want := atan2(to_home.x, to_home.z)
					pivot.rotation.y = lerp_angle(pivot.rotation.y, want, dt * 8.0)
	position.x = clampf(position.x, BOUNDS.position.x, BOUNDS.end.x)
	position.z = clampf(position.z, BOUNDS.position.y, BOUNDS.end.y)
	if state != St.AIR:
		position.y = 0.0
	if state == St.IDLE or state == St.STAGGER or state == St.GETUP:
		pivot.rotation.y = lerp_angle(pivot.rotation.y, 0.0, dt * 3.0)
	lie = smoothstep(0.0, 1.0, fall)
	pivot.rotation.x = -PI * 0.5 * lie
	pivot.position.y = lie_lift * lie
	if (state == St.KO or state == St.DOWN) and fall >= 1.0:
		pivot.rotation.z = sin(clock * 2.6) * 0.18
	else:
		pivot.rotation.z = lerpf(pivot.rotation.z, 0.0, dt * 6.0)


func _update_taunt(dt: float) -> void:
	if taunt_kind >= 0:
		taunt_t += dt
		if taunt_t > 2.6 or state != St.IDLE:
			taunt_kind = -1
		return
	if state == St.IDLE and since_hit > 2.5 and hp > 0.0 and panic <= 0.0:
		taunt_cd -= dt
		if taunt_cd <= 0.0:
			taunt_kind = randi() % 4
			taunt_t = 0.0
			taunt_cd = randf_range(4.5, 8.0)
			say(taunts.pick_random(), 2.2)


func _update_springs(dt: float) -> void:
	for n in j:
		var k := 95.0
		var c := 7.5
		if n.begins_with("arm") or n.begins_with("fore"):
			k = 45.0
			c = 4.5
		elif n.begins_with("tail"):
			k = 25.0
			c = 2.4
		elif n == "head":
			k = 70.0
			c = 6.0
		var s: Vector3 = spring[n]
		var v: Vector3 = spring_v[n]
		v += (-k * s - c * v) * dt
		s += v * dt
		if s.length() > 1.6:
			s = s.normalized() * 1.6
		spring[n] = s
		spring_v[n] = v


func _base_pose() -> Dictionary:
	var b := {}
	var t := clock
	model.position = Vector3.ZERO
	match state:
		St.AIR:
			b["arm_l"] = Vector3(sin(t * 19.0) * 0.5, 0, 2.0 + sin(t * 23.0) * 0.4)
			b["arm_r"] = Vector3(cos(t * 21.0) * 0.5, 0, -2.0 - sin(t * 17.0) * 0.4)
			b["leg_l"] = Vector3(sin(t * 18.0) * 0.7, 0, 0.2)
			b["leg_r"] = Vector3(-sin(t * 18.0) * 0.7, 0, -0.2)
			b["shin_l"] = Vector3(0.6 + sin(t * 15.0) * 0.4, 0, 0)
			b["shin_r"] = Vector3(0.6 - sin(t * 15.0) * 0.4, 0, 0)
		St.DOWN, St.KO, St.GETUP:
			var w := smoothstep(0.0, 1.0, fall)
			var tw := 0.0
			if state == St.KO and fmod(t, 2.7) < 0.35:
				tw = sin(t * 40.0) * 0.25
			b["arm_l"] = Vector3(-0.3, 0, 1.35 + tw) * w
			b["arm_r"] = Vector3(-0.3, 0, -1.35 - tw) * w
			b["forearm_l"] = Vector3(-0.4, 0, 0) * w
			b["forearm_r"] = Vector3(-0.4 + tw, 0, 0) * w
			var kick := sin(t * 7.0) * 0.35 if state == St.DOWN else tw
			b["leg_l"] = Vector3(-0.35 + kick, 0, 0.3) * w
			b["leg_r"] = Vector3(-0.35 - kick, 0, -0.3) * w
			b["shin_l"] = Vector3(0.5, 0, 0) * w
			b["shin_r"] = Vector3(0.5, 0, 0) * w
			b["head"] = Vector3(-0.2, sin(t * 1.3) * 0.3, 0) * w
		St.WALK:
			var s := sin(t * 9.0)
			b["leg_l"] = Vector3(-s * 0.55, 0, 0)
			b["leg_r"] = Vector3(s * 0.55, 0, 0)
			b["shin_l"] = Vector3(maxf(0.0, s) * 0.7, 0, 0)
			b["shin_r"] = Vector3(maxf(0.0, -s) * 0.7, 0, 0)
			b["arm_l"] = Vector3(s * 0.5, 0, 0.12)
			b["arm_r"] = Vector3(-s * 0.5, 0, -0.12)
			b["torso"] = Vector3(0.1, s * 0.1, 0)
			model.position.y = absf(cos(t * 9.0)) * 0.04
		_:
			_idle_pose(b, t)
	if j.has("tail1"):
		var wag := 3.0 + (8.0 if panic > 0.0 else 0.0)
		b["tail1"] = Vector3(sin(t * wag) * 0.15, sin(t * wag * 0.7) * 0.3, 0)
		b["tail2"] = Vector3(sin(t * wag - 0.7) * 0.25, sin(t * wag * 0.7 - 0.7) * 0.35, 0)
		b["tail3"] = Vector3(sin(t * wag - 1.4) * 0.35, sin(t * wag * 0.7 - 1.4) * 0.4, 0)
	return b


func _idle_pose(b: Dictionary, t: float) -> void:
	var br := sin(t * 2.2)
	var torso := Vector3(br * 0.025, 0, 0)
	var head := Vector3(-br * 0.02, 0, 0)
	var al := Vector3(0, 0, 0.12 + br * 0.03)
	var ar := Vector3(0, 0, -0.12 - br * 0.03)
	if hp / max_hp < 0.35:
		torso.x += 0.3
		head.x += 0.25
		al.z = 0.05
		ar.z = -0.05
		b["leg_l"] = Vector3(-0.25, 0, 0.06)
		b["leg_r"] = Vector3(-0.25, 0, -0.06)
		b["shin_l"] = Vector3(0.35 + sin(t * 7.0) * 0.08, 0, 0)
		b["shin_r"] = Vector3(0.35 - sin(t * 7.0) * 0.08, 0, 0)
		model.position.y = -0.05
	if dizzy > 0.0:
		torso.z += sin(t * 5.0) * 0.18
		torso.x += cos(t * 5.0) * 0.1
		head.z += sin(t * 5.0 + 1.0) * 0.2
	if panic > 0.0:
		var p := sin(t * 16.0)
		b["leg_l"] = Vector3(-maxf(0.0, p) * 1.1, 0, 0)
		b["shin_l"] = Vector3(maxf(0.0, p) * 1.5, 0, 0)
		b["leg_r"] = Vector3(-maxf(0.0, -p) * 1.1, 0, 0)
		b["shin_r"] = Vector3(maxf(0.0, -p) * 1.5, 0, 0)
		al = Vector3(0, 0, 2.5 + sin(t * 21.0) * 0.35)
		ar = Vector3(0, 0, -2.5 - sin(t * 19.0) * 0.35)
		head.x -= 0.25
		model.position.y = absf(p) * 0.13
	elif taunt_kind >= 0:
		var tt := taunt_t
		match taunt_kind:
			0:
				var s := sin(tt * 8.0)
				b["hips"] = Vector3(0, 0, s * 0.16)
				torso.z -= s * 0.24
				al = Vector3(0, 0, 2.5 + s * 0.3)
				ar = Vector3(0, 0, -2.5 + s * 0.3)
				b["forearm_l"] = Vector3(-0.6, 0, 0)
				b["forearm_r"] = Vector3(-0.6, 0, 0)
				model.position.y = absf(sin(tt * 8.0)) * 0.05
			1:
				ar = Vector3(-1.45, 0, -0.15)
				b["forearm_r"] = Vector3(-0.7 - sin(tt * 11.0) * 0.6, 0, 0)
				al = Vector3(0, 0, 0.5)
				b["forearm_l"] = Vector3(-1.8, 0, 0)
				head.z += 0.2
				b["hips"] = Vector3(0, sin(tt * 3.0) * 0.15, 0)
			2:
				torso.x += -0.22 + sin(tt * 18.0) * 0.07
				head.x -= 0.35
				al = Vector3(-0.55, 0, 0.35)
				ar = Vector3(-0.55, 0, -0.35)
				b["forearm_l"] = Vector3(-1.5, 0, 0)
				b["forearm_r"] = Vector3(-1.5, 0, 0)
				model.position.y = absf(sin(tt * 18.0)) * 0.02
			3:
				var pl := maxf(0.0, sin(tt * 10.0))
				var pr := maxf(0.0, -sin(tt * 10.0))
				al = Vector3(-0.7 - pl * 0.9, 0, 0.2)
				ar = Vector3(-0.7 - pr * 0.9, 0, -0.2)
				b["forearm_l"] = Vector3(-1.6 + pl * 1.4, 0, 0)
				b["forearm_r"] = Vector3(-1.6 + pr * 1.4, 0, 0)
				torso.y += (pl - pr) * 0.25
				b["leg_l"] = Vector3(-0.2, 0, 0.08)
				b["shin_l"] = Vector3(0.25, 0, 0)
				model.position.y = absf(sin(tt * 10.0)) * 0.04
	b["torso"] = torso
	b["head"] = head
	b["arm_l"] = al
	b["arm_r"] = ar


func _apply_pose(base: Dictionary) -> void:
	for n in j:
		var node := j[n] as Node3D
		var r: Vector3 = base.get(n, Vector3.ZERO)
		node.rotation = r + (spring[n] as Vector3)


func _update_face(dt: float) -> void:
	var eyes := "open"
	var mouth := "smile"
	if state == St.KO:
		eyes = "ko"
		mouth = "open"
	elif dizzy > 0.0:
		eyes = "dizzy"
		mouth = "open"
	elif state == St.AIR or state == St.DOWN or hurt_face > 0.0 or panic > 0.0:
		eyes = "hurt"
		mouth = "open"
	elif taunt_kind == 2:
		eyes = "hurt"
		mouth = "open"
	elif hp / max_hp < 0.35:
		mouth = "open"
	for e in ["open", "hurt", "ko", "dizzy"]:
		_show("eyes_" + e, e == eyes)
	_show("mouth_smile", mouth == "smile")
	_show("mouth_open", mouth == "open")
	blink_t -= dt
	var eo: Node3D = faces.get("eyes_open")
	if eo:
		eo.scale.y = 0.12 if blink_t < 0.0 else 1.0
	if blink_t < -0.12:
		blink_t = randf_range(2.0, 4.5)


func _step_squash(dt: float) -> void:
	if squash_hold <= 0.0:
		squash_v += (-230.0 * squash - 8.0 * squash_v) * dt
		squash += squash_v * dt
		squash = clampf(squash, -0.5, 0.85)


func _update_squash(dt: float) -> void:
	if squash_hold > 0.0:
		squash_hold -= dt
		if squash_hold <= 0.0 and main:
			main.sfx("boing", -2.0, randf_range(0.9, 1.1))
	scale = Vector3(1.0 + squash * 0.55, maxf(0.15, 1.0 - squash), 1.0 + squash * 0.55)
