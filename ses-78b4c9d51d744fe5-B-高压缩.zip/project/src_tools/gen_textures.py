# Generates all bitmap textures used by the Blender build and by Godot.
# Run with system python3 (needs Pillow):  python3 gen_textures.py <out_dir>
import math, os, random, sys
from PIL import Image, ImageDraw, ImageFont, ImageFilter

OUT = sys.argv[1] if len(sys.argv) > 1 else "../assets"
TMP = sys.argv[2] if len(sys.argv) > 2 else "/tmp/tex_build"
os.makedirs(OUT, exist_ok=True)
os.makedirs(TMP, exist_ok=True)
CJK = "/usr/share/fonts/opentype/noto/NotoSansCJK-Black.ttc"
CJK_IDX = 2  # Simplified Chinese face
random.seed(7)


def font(size):
    return ImageFont.truetype(CJK, size, index=CJK_IDX)


def text_img(text, size, fill, stroke=0, stroke_fill=None):
    f = font(size)
    l, t, r, b = f.getbbox(text, stroke_width=stroke)
    im = Image.new("RGBA", (r - l + 8, b - t + 8), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.text((4 - l, 4 - t), text, font=f, fill=fill, stroke_width=stroke, stroke_fill=stroke_fill)
    return im


def paste_text(img, text, cx, cy, height, xscale, fill, stroke=0, stroke_fill=None):
    """Draw text centred at (cx,cy) with a given pixel height and horizontal squash."""
    t = text_img(text, 200, fill, stroke, stroke_fill)
    h = height
    w = max(1, int(t.width * (h / t.height) * xscale))
    t = t.resize((w, h), Image.LANCZOS)
    img.alpha_composite(t, (int(cx - w / 2), int(cy - h / 2)))


# ---------------------------------------------------------------- jerseys
# Torso UV: u = around (0.25 front centre, 0.75 back centre), v = 0 waist -> 1 collar.
W, H = 1024, 512
XS = 0.62  # compensates horizontal stretch of the cylindrical mapping


def jersey_turtle():
    img = Image.new("RGBA", (W, H), (246, 246, 244, 255))
    d = ImageDraw.Draw(img)
    navy, gold = (24, 36, 84, 255), (214, 170, 60, 255)
    # subtle side panels
    for cx in (0, 512, 1024):
        d.rectangle((cx - 40, 0, cx + 40, H), fill=(232, 233, 236, 255))
    # collar + hem
    d.rectangle((0, 0, W, 34), fill=navy)
    d.rectangle((0, 34, W, 42), fill=gold)
    d.rectangle((0, H - 22, W, H), fill=navy)
    # front: badge + number
    fx = 256
    d.ellipse((fx + 40, 120, fx + 92, 172), fill=gold, outline=navy, width=5)
    paste_text(img, "龟", fx + 66, 146, 30, 1.0, navy)
    paste_text(img, "10", fx, 300, 150, XS, navy, 8, gold)
    # back: name + big number
    bx = 768
    paste_text(img, "神龟", bx, 120, 80, XS, navy, 4, gold)
    paste_text(img, "10", bx, 320, 250, XS, navy, 10, gold)
    img.save(os.path.join(OUT, "jersey_turtle.png"))


def jersey_mouse():
    img = Image.new("RGBA", (W, H), (255, 255, 255, 255))
    d = ImageDraw.Draw(img)
    sky = (110, 172, 228, 255)
    stripes = 22
    sw = W / stripes
    for i in range(stripes):
        if i % 2 == 0:
            x0 = i * sw + sw * 0.5
            d.rectangle((x0, 0, x0 + sw, H), fill=sky)
    black = (18, 18, 22, 255)
    d.rectangle((0, 0, W, 30), fill=black)
    d.rectangle((0, 30, W, 37), fill=sky)
    d.rectangle((0, H - 20, W, H), fill=black)
    fx = 256
    # badge with three stars
    d.polygon([(fx + 44, 130), (fx + 96, 130), (fx + 96, 160), (fx + 70, 185), (fx + 44, 160)], fill=sky, outline=black)
    d.rectangle((fx + 44, 145, fx + 96, 152), fill=(255, 255, 255, 255))
    for k in range(3):
        sx = fx + 52 + k * 18
        star(d, sx, 116, 8, (230, 190, 60, 255))
    paste_text(img, "10", fx, 300, 140, XS, black, 7, (255, 255, 255, 255))
    bx = 768
    paste_text(img, "呦西", bx, 120, 80, XS, black, 6, (255, 255, 255, 255))
    paste_text(img, "10", bx, 320, 250, XS, black, 10, (255, 255, 255, 255))
    img.save(os.path.join(OUT, "jersey_mouse.png"))


def star(d, cx, cy, r, fill):
    pts = []
    for i in range(10):
        a = -math.pi / 2 + i * math.pi / 5
        rr = r if i % 2 == 0 else r * 0.45
        pts.append((cx + rr * math.cos(a), cy + rr * math.sin(a)))
    d.polygon(pts, fill=fill)


# ---------------------------------------------------------------- shell
def shell():
    S = 512
    img = Image.new("RGBA", (S, S), (70, 98, 40, 255))
    d = ImageDraw.Draw(img)
    c = S / 2
    # scutes: hexagon grid inside the dome footprint
    hr = 62
    for row in range(-4, 5):
        for col in range(-4, 5):
            x = c + col * hr * 1.5
            y = c + row * hr * math.sqrt(3) + (col % 2) * hr * math.sqrt(3) / 2
            if math.hypot(x - c, y - c) > S * 0.47:
                continue
            pts = [(x + hr * 0.92 * math.cos(math.pi / 3 * k), y + hr * 0.92 * math.sin(math.pi / 3 * k)) for k in range(6)]
            tone = random.randint(-10, 10)
            d.polygon(pts, fill=(112 + tone, 140 + tone, 62 + tone, 255), outline=(48, 62, 26, 255))
            inner = [(x + hr * 0.55 * math.cos(math.pi / 3 * k), y + hr * 0.55 * math.sin(math.pi / 3 * k)) for k in range(6)]
            d.polygon(inner, fill=(128 + tone, 158 + tone, 74 + tone, 255))
    # marginal ring
    d.ellipse((6, 6, S - 6, S - 6), outline=(176, 150, 70, 255), width=26)
    img = img.filter(ImageFilter.GaussianBlur(1.2))
    # painted number (u = x, v = up)
    paste_text(img, "10", c, c + 30, 170, 1.0, (250, 250, 250, 255), 6, (30, 40, 80, 255))
    paste_text(img, "神龟", c, c - 95, 62, 1.0, (250, 250, 250, 255), 4, (30, 40, 80, 255))
    img.save(os.path.join(OUT, "shell.png"))


# ---------------------------------------------------------------- grass
def grass():
    S = 256
    img = Image.new("RGB", (S, S))
    px = img.load()
    for y in range(S):
        for x in range(S):
            n = random.random()
            v = 200 + int(40 * n)
            px[x, y] = (v, v, v)
    img = img.filter(ImageFilter.GaussianBlur(0.7))
    img.save(os.path.join(OUT, "grass.png"))


# ---------------------------------------------------------------- ads
def ads():
    img = Image.new("RGBA", (1024, 512), (0, 0, 0, 255))
    rows = [
        ("解压专用 · 暴打神龟", (255, 220, 40, 255), (150, 10, 20, 255)),
        ("呦西呦西 打你没商量", (120, 220, 255, 255), (10, 30, 90, 255)),
        ("专治各种不服", (255, 255, 255, 255), (20, 120, 50, 255)),
        ("今日发泄指数 MAX", (255, 120, 200, 255), (60, 10, 80, 255)),
    ]
    d = ImageDraw.Draw(img)
    for i, (t, fg, bg) in enumerate(rows):
        y0 = i * 128
        d.rectangle((0, y0, 1024, y0 + 128), fill=bg)
        for k in range(0, 1024, 8):
            d.line((k, y0, k, y0 + 128), fill=(0, 0, 0, 60))
        paste_text(img, t, 512, y0 + 64, 86, 1.0, fg, 3, (0, 0, 0, 255))
    img.save(os.path.join(OUT, "ads.png"))


# ---------------------------------------------------------------- patch atlas (Godot side)
def blob(d, cx, cy, r, fill, n=14, jitter=0.35):
    pts = []
    for i in range(n):
        a = i / n * math.tau
        rr = r * (1 + random.uniform(-jitter, jitter))
        pts.append((cx + rr * math.cos(a), cy + rr * math.sin(a)))
    d.polygon(pts, fill=fill)


def patches():
    C = 128
    img = Image.new("RGBA", (C * 4, C * 2), (0, 0, 0, 0))

    def cell(i):
        return Image.new("RGBA", (C, C), (0, 0, 0, 0))

    def put(i, im):
        img.alpha_composite(im, ((i % 4) * C, (i // 4) * C))

    # 0 bruise
    im = cell(0)
    d = ImageDraw.Draw(im)
    blob(d, 64, 64, 40, (90, 40, 120, 200))
    blob(d, 62, 66, 26, (60, 30, 110, 230))
    blob(d, 66, 60, 12, (150, 40, 80, 200))
    put(0, im.filter(ImageFilter.GaussianBlur(5)))
    # 1 egg splat
    im = cell(1)
    d = ImageDraw.Draw(im)
    for k in range(9):
        a = random.uniform(0, math.tau)
        rr = random.uniform(20, 50)
        blob(d, 64 + rr * math.cos(a), 64 + rr * math.sin(a), random.uniform(6, 13), (250, 248, 225, 235))
    blob(d, 64, 64, 40, (250, 248, 225, 235), 18, 0.3)
    blob(d, 60, 62, 20, (255, 190, 20, 255), 16, 0.12)
    d.ellipse((50, 52, 60, 58), fill=(255, 240, 160, 255))
    put(1, im.filter(ImageFilter.GaussianBlur(0.8)))
    # 2 slipper print
    im = cell(2)
    d = ImageDraw.Draw(im)
    d.ellipse((38, 8, 90, 70), fill=(220, 40, 50, 210))
    d.ellipse((44, 60, 84, 120), fill=(220, 40, 50, 210))
    d.rectangle((46, 40, 84, 90), fill=(220, 40, 50, 210))
    for k in range(6):
        d.line((44, 20 + k * 17, 86, 20 + k * 17), fill=(170, 20, 30, 230), width=3)
    put(2, im.filter(ImageFilter.GaussianBlur(1.5)))
    # 3 soot
    im = cell(3)
    d = ImageDraw.Draw(im)
    blob(d, 64, 64, 50, (20, 18, 16, 210), 20, 0.4)
    blob(d, 64, 64, 30, (5, 5, 5, 240))
    put(3, im.filter(ImageFilter.GaussianBlur(4)))
    # 4 red slap mark
    im = cell(4)
    d = ImageDraw.Draw(im)
    d.ellipse((30, 40, 98, 112), fill=(235, 50, 60, 170))
    for k in range(4):
        d.rounded_rectangle((28 + k * 18, 6 + abs(1.5 - k) * 8, 42 + k * 18, 60), 7, fill=(235, 50, 60, 170))
    put(4, im.filter(ImageFilter.GaussianBlur(3)))
    # 5 ball print
    im = cell(5)
    d = ImageDraw.Draw(im)
    d.ellipse((14, 14, 114, 114), fill=(120, 100, 70, 150))
    for k in range(5):
        a = -math.pi / 2 + k * math.tau / 5
        d.regular_polygon((64 + 34 * math.cos(a), 64 + 34 * math.sin(a), 12), 5, fill=(70, 55, 35, 190))
    d.regular_polygon((64, 64, 14), 5, fill=(70, 55, 35, 190))
    put(5, im.filter(ImageFilter.GaussianBlur(2)))
    # 6 band-aid
    im = cell(6)
    d = ImageDraw.Draw(im)
    for ang in (35, -35):
        b = Image.new("RGBA", (C, C), (0, 0, 0, 0))
        bd = ImageDraw.Draw(b)
        bd.rounded_rectangle((8, 48, 120, 80), 14, fill=(232, 196, 150, 255), outline=(190, 150, 110, 255), width=2)
        bd.rectangle((48, 50, 80, 78), fill=(250, 235, 215, 255))
        for k in range(4):
            for j in range(2):
                bd.ellipse((18 + k * 7 + (j * 70), 58 + j * 0, 21 + k * 7 + (j * 70), 61), fill=(200, 160, 120, 255))
        b = b.rotate(ang, resample=Image.BICUBIC)
        im.alpha_composite(b)
    put(6, im)
    # 7 dirt / grass stain
    im = cell(7)
    d = ImageDraw.Draw(im)
    blob(d, 64, 64, 44, (90, 110, 40, 150), 18, 0.45)
    blob(d, 70, 60, 24, (100, 80, 40, 170))
    put(7, im.filter(ImageFilter.GaussianBlur(3)))
    img.save(os.path.join(OUT, "patches.png"))


# ---------------------------------------------------------------- fx atlas (4 cells: dot, star, puff, plus)
def fx():
    C = 128
    img = Image.new("RGBA", (C * 4, C), (0, 0, 0, 0))
    # soft dot
    im = Image.new("RGBA", (C, C), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.ellipse((24, 24, 104, 104), fill=(255, 255, 255, 255))
    img.alpha_composite(im.filter(ImageFilter.GaussianBlur(10)), (0, 0))
    # star
    im = Image.new("RGBA", (C, C), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    star(d, 64, 66, 58, (255, 255, 255, 255))
    img.alpha_composite(im.filter(ImageFilter.GaussianBlur(1)), (C, 0))
    # puff
    im = Image.new("RGBA", (C, C), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    for k in range(7):
        a = k / 7 * math.tau
        d.ellipse((64 + 22 * math.cos(a) - 30, 64 + 22 * math.sin(a) - 30, 64 + 22 * math.cos(a) + 30, 64 + 22 * math.sin(a) + 30), fill=(255, 255, 255, 200))
    d.ellipse((30, 30, 98, 98), fill=(255, 255, 255, 230))
    img.alpha_composite(im.filter(ImageFilter.GaussianBlur(6)), (C * 2, 0))
    # plus
    im = Image.new("RGBA", (C, C), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((48, 14, 80, 114), 8, fill=(255, 255, 255, 255))
    d.rounded_rectangle((14, 48, 114, 80), 8, fill=(255, 255, 255, 255))
    img.alpha_composite(im.filter(ImageFilter.GaussianBlur(1)), (C * 3, 0))
    img.save(os.path.join(OUT, "fx.png"))


jersey_turtle()
jersey_mouse()
shell()
grass()
ads()
patches()
fx()
print("textures ok")
