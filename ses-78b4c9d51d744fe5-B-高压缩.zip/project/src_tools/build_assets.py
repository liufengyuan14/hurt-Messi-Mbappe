# Procedural asset build for 暴打神龟呦西.
# blender -b -P build_assets.py -- <out_dir> <texture_dir>
# Characters are built from rigid parts whose object origins sit on the joints, so
# Godot can animate them procedurally (rotate hips/torso/head/arms/legs nodes).
import bpy, bmesh, math, os, sys, random
from mathutils import Vector, Matrix

argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
OUT = argv[0] if len(argv) > 0 else "/workspace/project/assets"
TEX = argv[1] if len(argv) > 1 else "/tmp/tex_build"
os.makedirs(OUT, exist_ok=True)
random.seed(42)
V = Vector
PI = math.pi


def T(x, y, z):
    return Matrix.Translation((x, y, z))


def Rx(a):
    return Matrix.Rotation(a, 4, "X")


def Ry(a):
    return Matrix.Rotation(a, 4, "Y")


def Rz(a):
    return Matrix.Rotation(a, 4, "Z")


def S(x, y, z):
    return Matrix.Diagonal((x, y, z, 1.0))


def lin(hexcol):
    h = hexcol.lstrip("#")
    c = [int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4)]
    return [x / 12.92 if x <= 0.04045 else ((x + 0.055) / 1.055) ** 2.4 for x in c]


MATS = {}


def reset():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    MATS.clear()


def mat(name, hexcol, rough=0.55, metal=0.0, tex=None, emit=0.0):
    if name in MATS:
        return MATS[name]
    m = bpy.data.materials.new(name)
    try:
        m.use_nodes = True
    except Exception:
        pass
    nt = m.node_tree
    b = nt.nodes.get("Principled BSDF")
    c = lin(hexcol)
    b.inputs["Base Color"].default_value = (*c, 1.0)
    b.inputs["Roughness"].default_value = rough
    b.inputs["Metallic"].default_value = metal
    if tex:
        img = bpy.data.images.load(os.path.join(TEX, tex))
        t = nt.nodes.new("ShaderNodeTexImage")
        t.image = img
        nt.links.new(t.outputs["Color"], b.inputs["Base Color"])
    if emit > 0:
        b.inputs["Emission Color"].default_value = (*c, 1.0)
        b.inputs["Emission Strength"].default_value = emit
    MATS[name] = m
    return m


def empty(name, parent=None, loc=(0, 0, 0)):
    ob = bpy.data.objects.new(name, None)
    bpy.context.scene.collection.objects.link(ob)
    if parent:
        ob.parent = parent
    ob.location = loc
    return ob


class Part:
    """Accumulates primitives into one mesh. `origin` is the object's pivot in parent space.
    Geometry is given in parent space, or in the part's own joint space when local=True."""

    def __init__(self, name, origin=(0, 0, 0), local=False):
        self.name = name
        self.origin = V(origin)
        self.pre = Matrix.Identity(4) if local else Matrix.Translation(-self.origin)
        self.bm = bmesh.new()
        self.uv = self.bm.loops.layers.uv.new("UVMap")
        self.mats = []

    def _mi(self, m):
        if m not in self.mats:
            self.mats.append(m)
        return self.mats.index(m)

    def grid(self, rows, m, vs, uv_fn=None, smooth=True, uscale=1.0, uoff=0.0):
        mi = self._mi(m)
        bm = self.bm
        n = len(rows[0])
        vrows = []
        for row in rows:
            if all((p - row[0]).length < 1e-7 for p in row):
                v = bm.verts.new(row[0])
                vrows.append([v] * n)
            else:
                vrows.append([bm.verts.new(p) for p in row])
        for i in range(len(rows) - 1):
            for j in range(n):
                j2 = (j + 1) % n
                quad = [vrows[i][j], vrows[i][j2], vrows[i + 1][j2], vrows[i + 1][j]]
                u0, u1 = uoff + j / n * uscale, uoff + (j + 1) / n * uscale
                uvq = [(u0, vs[i]), (u1, vs[i]), (u1, vs[i + 1]), (u0, vs[i + 1])]
                verts, uvl = [], []
                for vv, uu in zip(quad, uvq):
                    if vv not in verts:
                        verts.append(vv)
                        uvl.append(uu)
                if len(verts) < 3:
                    continue
                try:
                    f = bm.faces.new(verts)
                except ValueError:
                    continue
                f.material_index = mi
                f.smooth = smooth
                for loop, uu in zip(f.loops, uvl):
                    if uv_fn:
                        loop[self.uv].uv = uv_fn(self.pre.inverted() @ loop.vert.co)
                    else:
                        loop[self.uv].uv = uu

    def lathe(self, m, prof, seg=24, sx=1.0, sy=1.0, M=None, uv_fn=None, vrange=None,
              smooth=True, uscale=1.0, phase=0.0, uoff=0.0):
        """Surface of revolution around local Z. prof = [(z, r)] ordered bottom -> top."""
        M = self.pre @ (M if M is not None else Matrix.Identity(4))
        rows = []
        for (z, r) in prof:
            row = []
            for j in range(seg):
                phi = PI + 2 * PI * j / seg + phase
                row.append(M @ V((sx * r * math.cos(phi), sy * r * math.sin(phi), z)))
            rows.append(row)
        zs = [p[0] for p in prof]
        z0, z1 = vrange if vrange else (min(zs), max(zs))
        vs = [(z - z0) / (z1 - z0) if z1 > z0 else 0.0 for z in zs]
        self.grid(rows, m, vs, uv_fn, smooth, uscale, uoff)

    def ell(self, m, c, r, seg=24, rings=14, M=None, uv_fn=None, smooth=True):
        prof = [(-math.cos(PI * i / rings), math.sin(PI * i / rings)) for i in range(rings + 1)]
        Mx = T(*c) @ (M if M is not None else Matrix.Identity(4)) @ S(r[0], r[1], r[2])
        self.lathe(m, prof, seg, 1, 1, Mx, uv_fn, smooth=smooth)

    def tube(self, m, pts, r, seg=8, caps=True, closed=False):
        pts = [V(p) for p in pts]
        n = len(pts)
        rs = list(r) if isinstance(r, (list, tuple)) else [r] * n
        rows = []
        side_prev = None
        for i, p in enumerate(pts):
            if closed:
                t = pts[(i + 1) % n] - pts[i - 1]
            elif i == 0:
                t = pts[1] - pts[0]
            elif i == n - 1:
                t = pts[-1] - pts[-2]
            else:
                t = pts[i + 1] - pts[i - 1]
            t.normalize()
            if side_prev is None:
                ref = V((0, 0, 1)) if abs(t.z) < 0.9 else V((1, 0, 0))
                side = t.cross(ref).normalized()
            else:
                side = (side_prev - t * side_prev.dot(t)).normalized()
            side_prev = side
            up = t.cross(side)
            rows.append([self.pre @ (p + (side * math.cos(2 * PI * j / seg) + up * math.sin(2 * PI * j / seg)) * rs[i])
                         for j in range(seg)])
        if closed:
            rows.append(rows[0])
        elif caps:
            t0 = (pts[1] - pts[0]).normalized()
            t1 = (pts[-1] - pts[-2]).normalized()
            rows.insert(0, [self.pre @ (pts[0] - t0 * rs[0] * 0.7)] * seg)
            rows.append([self.pre @ (pts[-1] + t1 * rs[-1] * 0.7)] * seg)
        vs = [i / max(1, len(rows) - 1) for i in range(len(rows))]
        self.grid(rows, m, vs)

    def torus(self, m, c, R, r, segR=32, segr=10, M=None, ry=None):
        ry = ry if ry is not None else R
        Mx = T(*c) @ (M if M is not None else Matrix.Identity(4))
        pts = [Mx @ V((R * math.cos(2 * PI * k / segR), ry * math.sin(2 * PI * k / segR), 0)) for k in range(segR)]
        self.tube(m, pts, r, segr, closed=True)

    def box(self, m, c, size, M=None):
        hx, hy, hz = size[0] / 2, size[1] / 2, size[2] / 2
        # 4-sided prism rotated 45deg -> axis aligned box
        Mx = T(*c) @ (M if M is not None else Matrix.Identity(4)) @ S(hx, hy, 1) @ Rz(PI / 4)
        self.lathe(m, [(-hz, 0.0), (-hz, math.sqrt(2)), (hz, math.sqrt(2)), (hz, 0.0)], 4, 1, 1, Mx, smooth=False)

    def build(self, parent=None):
        me = bpy.data.meshes.new(self.name)
        self.bm.normal_update()
        self.bm.to_mesh(me)
        self.bm.free()
        for m in self.mats:
            me.materials.append(m)
        ob = bpy.data.objects.new(self.name, me)
        bpy.context.scene.collection.objects.link(ob)
        if parent:
            ob.parent = parent
        ob.location = self.origin
        return ob


def export(fname):
    path = os.path.join(OUT, fname)
    bpy.ops.export_scene.gltf(filepath=path, export_format="GLB", export_apply=True, export_yup=True,
                              export_animations=False, export_cameras=False, export_materials="EXPORT",
                              export_image_format="AUTO")
    print("EXPORTED", path, len(bpy.data.objects), "objects")


def ell_front(c, r, x, z):
    dx = (x - c[0]) / r[0]
    dz = (z - c[2]) / r[2]
    k = max(0.0, 1 - dx * dx - dz * dz)
    return c[1] - r[1] * math.sqrt(k)


def ell_surface(c, r, d):
    d = V(d).normalized()
    t = 1.0 / math.sqrt((d.x / r[0]) ** 2 + (d.y / r[1]) ** 2 + (d.z / r[2]) ** 2)
    p = V(c) + d * t
    n = V(((p.x - c[0]) / r[0] ** 2, (p.y - c[1]) / r[1] ** 2, (p.z - c[2]) / r[2] ** 2)).normalized()
    return p, n


# ------------------------------------------------------------------ shared humanoid body
def humanoid(name, D, M, extra_torso=None, head_fn=None, extra_hips=None):
    root = empty(name)
    hz, tz, nz = D["hip_z"], D["torso_z"], D["neck_z"]
    # hips
    hips = Part("hips", (0, 0, hz))
    hr = D["hip_r"]
    hips.lathe(M["shorts"], [(hz - 0.13, 0.0), (hz - 0.125, hr * 0.55), (hz - 0.08, hr * 0.92), (hz, hr),
                             (hz + 0.08, hr * 1.0), (hz + 0.14, hr * 0.96)], 28, 1.0, 0.8)
    if extra_hips:
        extra_hips(hips)
    hips_o = hips.build(root)

    # torso (geometry in torso-joint space)
    tor = Part("torso", (0, 0, tz - hz), local=True)
    prof = D["jersey"]
    tor.lathe(M["jersey"], prof, 40, 1.0, D["depth"], vrange=(prof[0][0], prof[-2][0]))
    nl = nz - tz
    tor.torus(M["collar"], (0, 0, nl - 0.01), D["collar_r"], 0.024, 28, 8, ry=D["collar_r"] * 0.88)
    if extra_torso:
        extra_torso(tor)
    tor_o = tor.build(hips_o)

    objs = {"root": root, "hips": hips_o, "torso": tor_o}

    # arms
    for side, sn in ((1, "l"), (-1, "r")):
        sx = side * D["shoulder_x"]
        arm = Part("arm_" + sn, (sx, 0, D["shoulder_z"]), local=True)
        k = D["arm_k"]
        L = D["upper_len"]
        arm.lathe(M["sleeve"], [(-0.16 * k, 0.078 * k), (-0.175 * k, 0.106 * k), (-0.06 * k, 0.112 * k), (0.02 * k, 0.106 * k),
                                (0.055 * k, 0.07 * k), (0.068 * k, 0.0)], 20, 1, 1, M=None,
                  uscale=D.get("sleeve_uscale", 1.0), uoff=D.get("sleeve_uoff", 0.0), vrange=D.get("sleeve_vrange"))
        arm.torus(M["trim"], (0, 0, -0.17 * k), 0.104 * k, 0.014 * k, 20, 6)
        arm.lathe(M["skin"], [(-L - 0.03, 0.062 * k), (-0.12, 0.074 * k), (0.0, 0.08 * k)], 16)
        if sn == "l" and "armband" in M:
            arm.torus(M["armband"], (0, 0, -0.11 * k), 0.113 * k, 0.022 * k, 20, 6, M=S(1, 1, 1.6))
        arm_o = arm.build(tor_o)
        fo = Part("forearm_" + sn, (0, 0, -L), local=True)
        F = D["fore_len"]
        fo.ell(M["skin"], (0, 0, 0), (0.07 * k, 0.07 * k, 0.07 * k), 16, 10)
        fo.lathe(M["skin"], [(-F, 0.055 * k), (-0.1, 0.064 * k), (0.0, 0.068 * k)], 16)
        hc = -F - 0.055 * k
        fo.ell(M["hand"], (0, -0.005, hc), (0.066 * k, 0.078 * k, 0.085 * k), 16, 10)
        fo.ell(M["hand"], (-side * 0.045 * k, -0.055 * k, hc + 0.03 * k), (0.03 * k, 0.03 * k, 0.042 * k), 10, 8)
        fo_o = fo.build(arm_o)
        objs["arm_" + sn] = arm_o
        objs["forearm_" + sn] = fo_o

    # legs
    for side, sn in ((1, "l"), (-1, "r")):
        leg = Part("leg_" + sn, (side * D["leg_x"], 0, -0.03), local=True)
        k = D["leg_k"]
        TL = D["thigh_len"]
        leg.lathe(M["skin"], [(-TL, 0.08 * k), (-0.2, 0.095 * k), (0.0, 0.105 * k)], 16)
        leg.lathe(M["shorts"], [(-0.17 * k, 0.096 * k), (-0.18 * k, 0.135 * k), (-0.1 * k, 0.142 * k), (0.04, 0.15 * k),
                                (0.09, 0.12 * k)], 20)
        leg.torus(M["trim"], (0, 0, -0.176 * k), 0.136 * k, 0.014 * k, 20, 6)
        leg_o = leg.build(hips_o)
        knee_abs = hz - 0.03 - TL
        sh = Part("shin_" + sn, (0, 0, -TL), local=True)
        sh.ell(M["skin"], (0, 0, 0), (0.084 * k, 0.084 * k, 0.084 * k), 16, 10)
        bz = -(knee_abs - 0.062)
        sh.lathe(M["sock"], [(bz + 0.01, 0.06 * k), (bz + 0.06, 0.066 * k), (-0.17, 0.088 * k), (-0.05, 0.085 * k),
                             (-0.02, 0.072 * k)], 18)
        sh.torus(M["sockband"], (0, 0, -0.06), 0.086 * k, 0.018 * k, 18, 6, M=S(1, 1, 1.4))
        sh.ell(M["boot"], (0, -0.05, bz), (0.088 * k, 0.15 * k, 0.062), 20, 12)
        sh.ell(M["sole"], (0, -0.05, -(knee_abs - 0.02)), (0.094 * k, 0.156 * k, 0.02), 20, 8)
        sh_o = sh.build(leg_o)
        objs["leg_" + sn] = leg_o
        objs["shin_" + sn] = sh_o

    head = Part("head", (0, 0, nz - tz), local=True)
    objs["head_part"] = head
    head_fn(objs, head)
    return objs


def face_lines(part, m, pts, r=0.011):
    part.tube(m, pts, r, 8)


def eyes_set(head_o, name, centers, face_y, mats, kind, scale=1.0):
    """centers: list of (side, ex, ez). Builds an expression child of head."""
    ey = sum(face_y(ex, ez) for (_, ex, ez) in centers) / len(centers)
    ez_avg = sum(c[2] for c in centers) / len(centers)
    p = Part(name, (0, ey, ez_avg))
    for (s, ex, ez) in centers:
        fy = face_y(ex, ez)
        k = scale
        if kind == "open":
            p.ell(mats["eye_w"], (ex, fy + 0.032 * k, ez), (0.068 * k, 0.05 * k, 0.08 * k), 20, 12)
            ef = fy + 0.032 * k - 0.05 * k
            p.ell(mats["pupil"], (ex - s * 0.004, ef + 0.008 * k, ez - 0.006), (0.034 * k, 0.013 * k, 0.043 * k), 16, 10)
            p.ell(mats["eye_w"], (ex - s * 0.014 * k, ef - 0.003, ez + 0.02 * k), (0.011 * k, 0.008, 0.011 * k), 10, 6)
        elif kind == "hurt":
            tip = ex - s * 0.03 * k
            a = ex + s * 0.035 * k
            pts = []
            for t in range(5):
                f = t / 4
                pts.append((a + (tip - a) * f, 0, ez + 0.036 * k * (1 - f)))
            for t in range(1, 5):
                f = t / 4
                pts.append((tip + (a - tip) * f, 0, ez - 0.036 * k * f))
            pts = [(x, face_y(x, z) - 0.006, z) for (x, _, z) in pts]
            p.tube(mats["line"], pts, 0.013 * k, 8)
        elif kind == "ko":
            for (dx0, dz0, dx1, dz1) in ((-1, -1, 1, 1), (-1, 1, 1, -1)):
                pts = []
                for t in range(6):
                    f = t / 5
                    x = ex + 0.036 * k * (dx0 + (dx1 - dx0) * f)
                    z = ez + 0.036 * k * (dz0 + (dz1 - dz0) * f)
                    pts.append((x, face_y(x, z) - 0.006, z))
                p.tube(mats["line"], pts, 0.012 * k, 8)
        elif kind == "dizzy":
            pts = []
            for t in range(22):
                a = t / 21 * PI * 3.2
                rr = 0.008 + 0.034 * k * t / 21
                x = ex + rr * math.cos(a)
                z = ez + rr * math.sin(a)
                pts.append((x, face_y(x, z) - 0.006, z))
            p.tube(mats["line"], pts, 0.009 * k, 6)
    return p.build(head_o)


def band_ring(part, m, c, r, tilt, z0, tube_r, seg=40):
    pts = []
    for k in range(seg):
        a = 2 * PI * k / seg
        d = V((math.cos(a), math.sin(a), 0))
        d = (Rx(tilt) @ d.to_4d()).to_3d()
        d.z += z0
        pnt, n = ell_surface(c, r, d)
        pts.append(pnt + n * tube_r * 0.45)
    part.tube(m, pts, tube_r, 10, closed=True)
    return pts


def afro_blobs(part, m, c, r, count=46, out=0.07, rad=(0.075, 0.1), face_guard=None):
    rnd = random.Random(5)
    made = 0
    tries = 0
    while made < count and tries < 4000:
        tries += 1
        d = V((rnd.uniform(-1, 1), rnd.uniform(-1, 1), rnd.uniform(-0.15, 1)))
        if d.length < 0.2:
            continue
        pnt, n = ell_surface(c, r, d)
        if face_guard and face_guard(pnt):
            continue
        rr = rnd.uniform(*rad)
        part.ell(m, tuple(pnt + n * out), (rr, rr, rr), 10, 7)
        made += 1


# ------------------------------------------------------------------ 神龟 (turtle)
def build_turtle():
    reset()
    M = {
        "skin": mat("t_skin", "#76B843", 0.5),
        "hand": mat("t_skin", "#76B843", 0.5),
        "skin_l": mat("t_skin_light", "#B9DC86", 0.5),
        "jersey": mat("t_jersey", "#FFFFFF", 0.7, tex="jersey_turtle.png"),
        "sleeve": mat("t_sleeve", "#F5F5F3", 0.7),
        "shorts": mat("t_shorts", "#F2F2F0", 0.7),
        "collar": mat("t_navy", "#1B2654", 0.6),
        "trim": mat("t_navy", "#1B2654", 0.6),
        "sock": mat("t_sock", "#F6F6F6", 0.8),
        "sockband": mat("t_navy", "#1B2654", 0.6),
        "boot": mat("t_boot", "#FF6F12", 0.3),
        "sole": mat("t_sole", "#FAFAFA", 0.5),
    }
    F = {
        "eye_w": mat("eye_white", "#FFFFFF", 0.2),
        "pupil": mat("eye_pupil", "#121212", 0.15),
        "line": mat("line_dark", "#1E2A14", 0.6),
        "mouth": mat("mouth", "#4A1416", 0.6),
        "tongue": mat("tongue", "#E8607A", 0.5),
        "teeth": mat("teeth", "#FFFFFF", 0.3),
        "brow": mat("t_brow", "#2F5A1A", 0.6),
        "band": mat("bandage", "#F7F5EC", 0.85),
        "cross": mat("red_cross", "#E53935", 0.6),
        "afro": mat("afro", "#16110E", 0.95),
    }
    shell = mat("t_shell", "#FFFFFF", 0.45, tex="shell.png")
    rim = mat("t_rim", "#C9A24E", 0.5)
    D = {
        "hip_z": 0.86, "torso_z": 0.95, "neck_z": 1.47, "hip_r": 0.25,
        "jersey": [(-0.08, 0.25), (0.0, 0.272), (0.12, 0.295), (0.25, 0.293), (0.35, 0.278), (0.42, 0.248),
                   (0.47, 0.19), (0.505, 0.125), (0.51, 0.0)],
        "depth": 0.8, "collar_r": 0.118,
        "shoulder_x": 0.305, "shoulder_z": 0.41, "arm_k": 1.0, "upper_len": 0.27, "fore_len": 0.21,
        "leg_x": 0.13, "leg_k": 1.0, "thigh_len": 0.40,
    }

    def torso_extra(tor):
        sc, sr = (0, 0.17, 0.215), (0.325, 0.2, 0.37)

        def uvf(p):
            return (0.5 - p.x / (2 * sr[0] * 1.02), 0.5 + (p.z - sc[2]) / (2 * sr[2] * 1.02))
        tor.ell(shell, sc, sr, 36, 20, uv_fn=uvf)
        tor.torus(rim, (0, 0.165, 0.215), 0.335, 0.034, 40, 8, M=Rx(PI / 2), ry=0.38)

    HC, HR = (0, -0.03, 0.22), (0.22, 0.24, 0.2)
    MC, MR = (0, -0.165, 0.15), (0.155, 0.135, 0.105)

    def face_y(x, z):
        return min(ell_front(HC, HR, x, z), ell_front(MC, MR, x, z))

    def head_fn(objs, head):
        head.lathe(M["skin"], [(-0.09, 0.098), (0.1, 0.094)], 18)
        head.ell(M["skin"], HC, HR, 32, 20)
        head.ell(M["skin_l"], MC, MR, 28, 16)
        for s in (1, -1):
            x = s * 0.034
            head.ell(F["line"], (x, face_y(x, 0.2) + 0.006, 0.2), (0.012, 0.01, 0.009), 8, 6)
            pts = []
            for t in range(6):
                f = t / 5
                bx = s * (0.04 + 0.12 * f)
                bz = 0.405 - 0.035 * f + 0.02 * math.sin(f * PI)
                pts.append((bx, face_y(bx, bz) - 0.004, bz))
            head.tube(F["brow"], pts, [0.018, 0.02, 0.02, 0.018, 0.015, 0.012], 8)
        head_o = head.build(objs["torso"])
        objs["head"] = head_o
        centers = [(1, 0.095, 0.305), (-1, -0.095, 0.305)]
        for kind in ("open", "hurt", "ko", "dizzy"):
            objs["eyes_" + kind] = eyes_set(head_o, "eyes_" + kind, centers, face_y, F, kind)
        # mouths
        sm = Part("mouth_smile", (0, face_y(0, 0.13), 0.13))
        pts = []
        for t in range(13):
            x = -0.11 + 0.22 * t / 12
            z = 0.135 + 0.045 * (x / 0.11) ** 2
            pts.append((x, face_y(x, z) - 0.002, z))
        sm.tube(F["mouth"], pts, 0.012, 8)
        # grin: row of teeth just under the smile line, mouth cavity below
        for t in range(9):
            x = -0.072 + 0.144 * t / 8
            z = 0.128 + 0.045 * (x / 0.11) ** 2
            sm.ell(F["teeth"], (x, face_y(x, z) + 0.003, z - 0.004), (0.0125, 0.008, 0.013), 8, 6)
        for t in range(7):
            x = -0.06 + 0.12 * t / 6
            z = 0.106 + 0.045 * (x / 0.11) ** 2
            sm.ell(F["mouth"], (x, face_y(x, z) + 0.006, z), (0.016, 0.008, 0.012), 8, 6)
        sm.build(head_o)
        mo = Part("mouth_open", (0, face_y(0, 0.12), 0.12))
        fy = face_y(0, 0.12)
        mo.ell(F["mouth"], (0, fy + 0.016, 0.115), (0.07, 0.032, 0.055), 20, 12)
        mo.ell(F["tongue"], (0, fy + 0.006, 0.09), (0.042, 0.02, 0.022), 14, 8)
        mo.ell(F["teeth"], (0, fy + 0.004, 0.158), (0.052, 0.012, 0.012), 14, 6)
        mo.build(head_o)
        # bandage
        bd = Part("bandage", (0, 0, 0.36))
        band_ring(bd, F["band"], HC, (HR[0] + 0.004, HR[1] + 0.004, HR[2] + 0.004), -0.42, 0.62, 0.032)
        bp, bn = ell_surface(HC, HR, (0.75, 0.55, 0.85))
        bd.ell(F["band"], tuple(bp + bn * 0.04), (0.045, 0.03, 0.035), 12, 8)
        bd.ell(F["band"], tuple(bp + bn * 0.05 + V((0.02, 0.05, -0.04))), (0.022, 0.05, 0.016), 10, 6)
        cp, cn = ell_surface(HC, HR, (-0.35, -0.5, 0.75))
        bd.box(F["band"], tuple(cp + cn * 0.008), (0.1, 0.012, 0.06), M=Ry(-0.4))
        bd.box(F["cross"], tuple(cp + cn * 0.016), (0.05, 0.006, 0.014), M=Ry(-0.4))
        bd.box(F["cross"], tuple(cp + cn * 0.016), (0.014, 0.006, 0.045), M=Ry(-0.4))
        bd.build(head_o)
        af = Part("afro", (0, 0, 0.38))
        afro_blobs(af, F["afro"], HC, HR, 52, 0.06, (0.08, 0.11),
                   face_guard=lambda p: (p.y < -0.12 and p.z < 0.42) or p.z < 0.2)
        af.build(head_o)
        stars = empty("star_anchor", head_o, (0, -0.03, 0.5))

    objs = humanoid("turtle", D, M, extra_torso=torso_extra, head_fn=head_fn)
    export("turtle.glb")


# ------------------------------------------------------------------ 呦西 (mouse)
def build_mouse():
    reset()
    M = {
        "skin": mat("m_fur", "#6E625C", 0.75),
        "hand": mat("m_pink", "#F0A2AE", 0.5),
        "jersey": mat("m_jersey", "#FFFFFF", 0.7, tex="jersey_mouse.png"),
        "sleeve": mat("m_jersey", "#FFFFFF", 0.7, tex="jersey_mouse.png"),
        "shorts": mat("m_shorts", "#1C1C22", 0.7),
        "collar": mat("m_black", "#141418", 0.6),
        "trim": mat("m_sky", "#74B3E8", 0.6),
        "sock": mat("m_sock", "#F6F6F6", 0.8),
        "sockband": mat("m_sky", "#74B3E8", 0.6),
        "boot": mat("m_boot", "#F2BE22", 0.3, 0.2),
        "sole": mat("m_sole", "#FAFAFA", 0.5),
        "armband": mat("m_armband", "#F4D03F", 0.5),
    }
    F = {
        "eye_w": mat("eye_white", "#FFFFFF", 0.2),
        "pupil": mat("eye_pupil", "#121212", 0.15),
        "line": mat("line_dark", "#1A1414", 0.6),
        "mouth": mat("mouth", "#4A1416", 0.6),
        "tongue": mat("tongue", "#E8607A", 0.5),
        "teeth": mat("teeth", "#FFFFFF", 0.3),
        "band": mat("bandage", "#F7F5EC", 0.85),
        "cross": mat("red_cross", "#E53935", 0.6),
        "afro": mat("afro", "#16110E", 0.95),
    }
    fur_l = mat("m_fur_light", "#B3A69C", 0.75)
    pink = M["hand"]
    beard = mat("m_beard", "#4A3123", 0.9)
    hair = mat("m_hair", "#5C3D27", 0.8)
    whisk = mat("m_whisker", "#2A2422", 0.5)
    D = {
        "hip_z": 0.70, "torso_z": 0.78, "neck_z": 1.22, "hip_r": 0.21,
        "jersey": [(-0.08, 0.212), (0.0, 0.228), (0.11, 0.24), (0.22, 0.236), (0.3, 0.225), (0.36, 0.2),
                   (0.405, 0.152), (0.435, 0.1), (0.44, 0.0)],
        "depth": 0.8, "collar_r": 0.096,
        "shoulder_x": 0.255, "shoulder_z": 0.335, "arm_k": 0.86, "upper_len": 0.225, "fore_len": 0.18,
        "leg_x": 0.105, "leg_k": 0.86, "thigh_len": 0.31,
        "sleeve_uscale": 0.28, "sleeve_uoff": 0.36, "sleeve_vrange": (-1.4, 1.0),
    }

    HC, HR = (0, -0.02, 0.2), (0.19, 0.19, 0.18)
    SN_BASE = V((0, -0.11, 0.145))
    SN_LEN = 0.22

    def snout_r(t):
        prof = [(0, 0.12), (0.06, 0.112), (0.12, 0.088), (0.17, 0.058), (0.2, 0.034), (0.22, 0.0)]
        for i in range(len(prof) - 1):
            if prof[i][0] <= t <= prof[i + 1][0]:
                f = (t - prof[i][0]) / (prof[i + 1][0] - prof[i][0])
                return prof[i][1] + (prof[i + 1][1] - prof[i][1]) * f
        return 0.0

    def face_y(x, z):
        y = ell_front(HC, HR, x, z)
        # snout (approximate as elliptic cone pointing -Y, vertical squash 0.85)
        best = y
        for i in range(40):
            t = SN_LEN * i / 39
            r = snout_r(t)
            dz = (z - SN_BASE.z) / 0.85
            if x * x + dz * dz <= r * r:
                best = min(best, SN_BASE.y - t)
        return best

    def head_fn(objs, head):
        head.lathe(M["skin"], [(-0.08, 0.085), (0.08, 0.08)], 18)
        head.ell(M["skin"], HC, HR, 32, 20)
        prof = [(0, 0.12), (0.06, 0.112), (0.12, 0.088), (0.17, 0.058), (0.2, 0.034), (0.22, 0.0)]
        head.lathe(fur_l, prof, 24, 1.0, 0.85, M=T(*SN_BASE) @ Rx(PI / 2))
        head.ell(pink, (0, SN_BASE.y - SN_LEN - 0.005, SN_BASE.z + 0.012), (0.042, 0.036, 0.034), 16, 10)
        # cheeks (lighter fur)
        for s in (1, -1):
            head.ell(fur_l, (s * 0.085, -0.13, 0.115), (0.07, 0.06, 0.055), 16, 10)
        # ears
        for s in (1, -1):
            ec = V((s * 0.165, 0.03, 0.355))
            R = Rz(s * 0.45) @ Ry(s * 0.35)
            head.ell(M["skin"], tuple(ec), (0.125, 0.03, 0.125), 24, 12, M=R)
            inner = ec + (R @ V((0, -0.016, 0, 0))).to_3d()
            head.ell(pink, tuple(inner), (0.088, 0.02, 0.088), 20, 10, M=R)
        # beard (dark brown along the jaw), hair swoop
        for k in range(11):
            a = -1.75 + 3.5 * k / 10
            z = 0.075 + 0.035 * abs(a) / 1.75
            p, n = ell_surface(HC, HR, (math.sin(a), -math.cos(a), (z - HC[2]) / 0.6))
            head.ell(beard, tuple(p + n * 0.012), (0.05, 0.04, 0.045), 12, 8)
        head.ell(beard, (0, -0.2, 0.06), (0.06, 0.045, 0.045), 12, 8)
        for s in (1, -1):
            pts = [(s * 0.05, SN_BASE.y - 0.12, 0.112), (s * 0.03, SN_BASE.y - 0.15, 0.108)]
            head.tube(beard, pts, 0.016, 8)
        head.ell(hair, (0, -0.0, 0.345), (0.165, 0.175, 0.07), 24, 12, M=Rx(-0.25))
        head.ell(hair, (0.045, -0.14, 0.33), (0.11, 0.06, 0.04), 16, 8, M=Ry(0.3))
        # whiskers
        for s in (1, -1):
            for k in (-1, 0, 1):
                y0 = SN_BASE.y - 0.17
                pts = [(s * 0.04, y0, 0.15 + k * 0.012), (s * 0.13, y0 - 0.01, 0.16 + k * 0.035),
                       (s * 0.22, y0 + 0.02, 0.165 + k * 0.06)]
                head.tube(whisk, pts, 0.004, 5)
        head_o = head.build(objs["torso"])
        objs["head"] = head_o
        centers = [(1, 0.078, 0.268), (-1, -0.078, 0.268)]
        for kind in ("open", "hurt", "ko", "dizzy"):
            objs["eyes_" + kind] = eyes_set(head_o, "eyes_" + kind, centers, face_y, F, kind, 0.86)
        ty = SN_BASE.y - 0.15
        tz = SN_BASE.z - snout_r(0.15) * 0.85
        sm = Part("mouth_smile", (0, ty, tz))
        for s in (1, -1):
            sm.box(F["teeth"], (s * 0.013, ty + 0.004, tz - 0.012), (0.022, 0.012, 0.034))
        pts = []
        for t in range(9):
            x = -0.06 + 0.12 * t / 8
            pts.append((x, ty + 0.02 + 0.07 * (x / 0.06) ** 2 * 0.5, tz + 0.004 + 0.02 * (x / 0.06) ** 2))
        sm.tube(F["mouth"], pts, 0.008, 6)
        sm.build(head_o)
        mo = Part("mouth_open", (0, ty, tz - 0.02))
        mo.ell(F["mouth"], (0, ty + 0.02, tz - 0.025), (0.055, 0.04, 0.04), 18, 10)
        mo.ell(F["tongue"], (0, ty + 0.01, tz - 0.045), (0.032, 0.02, 0.016), 12, 8)
        for s in (1, -1):
            mo.box(F["teeth"], (s * 0.013, ty + 0.004, tz - 0.004), (0.022, 0.012, 0.03))
        mo.build(head_o)
        bd = Part("bandage", (0, 0, 0.32))
        band_ring(bd, F["band"], HC, (HR[0] + 0.004, HR[1] + 0.004, HR[2] + 0.004), -0.45, 0.62, 0.028)
        bp, bn = ell_surface(HC, HR, (-0.75, 0.55, 0.8))
        bd.ell(F["band"], tuple(bp + bn * 0.035), (0.04, 0.028, 0.032), 12, 8)
        bd.ell(F["band"], tuple(bp + bn * 0.045 + V((-0.02, 0.045, -0.035))), (0.02, 0.045, 0.014), 10, 6)
        cp, cn = ell_surface(HC, HR, (0.45, -0.55, 0.55))
        bd.box(F["band"], tuple(cp + cn * 0.008), (0.085, 0.012, 0.05), M=Rz(0.5) @ Ry(0.5))
        bd.box(F["cross"], tuple(cp + cn * 0.016), (0.042, 0.006, 0.012), M=Rz(0.5) @ Ry(0.5))
        bd.box(F["cross"], tuple(cp + cn * 0.016), (0.012, 0.006, 0.038), M=Rz(0.5) @ Ry(0.5))
        bd.build(head_o)
        af = Part("afro", (0, 0, 0.36))
        afro_blobs(af, F["afro"], HC, HR, 50, 0.06, (0.07, 0.1),
                   face_guard=lambda p: (p.y < -0.1 and p.z < 0.36) or p.z < 0.18)
        af.build(head_o)
        empty("star_anchor", head_o, (0, -0.02, 0.48))

    objs = humanoid("mouse", D, M, head_fn=head_fn)
    # tail chain on hips
    hips_o = objs["hips"]
    A, B, C = V((0, 0.16, -0.06)), V((0, 0.42, -0.1)), V((0, 0.62, 0.0))
    D_, E = V((0, 0.7, 0.2)), V((0, 0.68, 0.32))
    t1 = Part("tail1", tuple(A), local=True)
    t1.tube(pink, [(0, -0.02, 0), (0, 0.13, -0.03), tuple(B - A)], [0.03, 0.027, 0.024], 10, caps=False)
    t1o = t1.build(hips_o)
    t2 = Part("tail2", tuple(B - A), local=True)
    t2.tube(pink, [(0, -0.01, 0), (0, 0.1, 0.03), tuple(C - B)], [0.024, 0.021, 0.018], 10, caps=False)
    t2o = t2.build(t1o)
    t3 = Part("tail3", tuple(C - B), local=True)
    t3.tube(pink, [(0, -0.01, 0), (0, 0.06, 0.1), tuple(D_ - C), tuple(E - C)], [0.018, 0.014, 0.01, 0.006], 10)
    t3.build(t2o)
    export("mouse.glb")


# ------------------------------------------------------------------ fan (helper attackers)
def build_fan(root_name="fan"):
    shirt = mat("fan_shirt", "#FFFFFF", 0.7)
    skin = mat("fan_skin", "#F1C27D", 0.6)
    hair = mat("fan_hair", "#2B1D14", 0.8)
    pants = mat("fan_pants", "#2E3440", 0.7)
    shoe = mat("fan_shoe", "#1A1A1A", 0.5)
    eye = mat("eye_pupil", "#121212", 0.15)
    mouth = mat("mouth", "#4A1416", 0.6)
    white = mat("eye_white", "#FFFFFF", 0.2)
    root = empty(root_name)
    body = Part("body", (0, 0, 0.62))
    body.lathe(shirt, [(0.40, 0.0), (0.41, 0.15), (0.48, 0.19), (0.62, 0.2), (0.75, 0.18), (0.82, 0.12), (0.84, 0.0)], 20)
    body.lathe(pants, [(0.33, 0.0), (0.34, 0.12), (0.4, 0.17), (0.46, 0.18)], 18)
    body.build(root)
    hd = Part("head", (0, 0, 0.84))
    hd.lathe(skin, [(0.8, 0.06), (0.88, 0.06)], 10)
    hd.ell(skin, (0, 0, 1.0), (0.19, 0.18, 0.19), 24, 14)
    hd.ell(hair, (0, 0.03, 1.08), (0.2, 0.19, 0.14), 20, 10, M=Rx(0.25))
    for s in (1, -1):
        hd.ell(white, (s * 0.065, -0.165, 1.02), (0.04, 0.02, 0.035), 10, 8)
        hd.ell(eye, (s * 0.062, -0.178, 1.015), (0.02, 0.012, 0.022), 8, 6)
        hd.tube(hair, [(s * 0.025, -0.175, 1.07), (s * 0.1, -0.165, 1.095)], 0.012, 6)
        hd.ell(skin, (s * 0.19, 0.0, 1.0), (0.03, 0.035, 0.05), 8, 6)
    hd.ell(mouth, (0, -0.172, 0.93), (0.05, 0.02, 0.035), 12, 8)
    hd.build(root)
    for s, sn in ((1, "l"), (-1, "r")):
        a = Part("arm_" + sn, (s * 0.22, 0, 0.78))
        a.lathe(shirt, [(0.64, 0.0), (0.64, 0.065), (0.72, 0.075), (0.8, 0.07), (0.82, 0.0)], 12, M=T(s * 0.22, 0, 0))
        a.lathe(skin, [(0.5, 0.05), (0.66, 0.055)], 12, M=T(s * 0.22, 0, 0))
        a.ell(skin, (s * 0.22, -0.01, 0.47), (0.06, 0.06, 0.065), 12, 8)
        a.build(root)
        lg = Part("leg_" + sn, (s * 0.085, 0, 0.42))
        lg.lathe(pants, [(0.06, 0.06), (0.42, 0.075)], 12, M=T(s * 0.085, 0, 0))
        lg.ell(shoe, (s * 0.085, -0.05, 0.04), (0.07, 0.12, 0.05), 12, 8)
        lg.build(root)
    return root


# ------------------------------------------------------------------ tools
def build_tools():
    # glove: points along +Y (Godot -Z), origin at cuff
    red = mat("glove_red", "#D7262B", 0.25)
    white = mat("tool_white", "#F4F4F4", 0.5)
    g = Part("glove")
    g.lathe(white, [(0.0, 0.0), (0.0, 0.085), (0.1, 0.09), (0.1, 0.0)], 20, M=Rx(-PI / 2))
    g.ell(red, (0, 0.21, 0.0), (0.14, 0.15, 0.13), 24, 14)
    g.ell(red, (0, 0.12, 0.0), (0.11, 0.1, 0.1), 20, 12)
    g.ell(red, (0.1, 0.16, -0.03), (0.055, 0.08, 0.06), 14, 10)
    g.ell(white, (0, 0.33, 0.06), (0.06, 0.03, 0.03), 10, 6)
    g.build()
    # slipper: extends along +Z (Godot +Y), sole bottom faces +Y (strike face)
    blue = mat("slipper_blue", "#2F7BE5", 0.45)
    strap = mat("slipper_strap", "#FFD23F", 0.45)
    sl = Part("slipper")
    sl.ell(blue, (0, 0.0, 0.08), (0.05, 0.016, 0.085), 24, 10)
    sl.ell(blue, (0, 0.0, 0.2), (0.062, 0.016, 0.1), 24, 10)
    sl.tube(strap, [(-0.05, -0.012, 0.15), (-0.02, -0.04, 0.2), (0, -0.016, 0.255)], 0.009, 6)
    sl.tube(strap, [(0.05, -0.012, 0.15), (0.02, -0.04, 0.2), (0, -0.016, 0.255)], 0.009, 6)
    sl.build()
    # frying pan
    pan = mat("pan_metal", "#2C2C30", 0.35, 0.8)
    pan_in = mat("pan_inside", "#3C3C42", 0.25, 0.7)
    wood = mat("wood", "#B97A43", 0.6)
    pn = Part("pan")
    prof = [(0.0, 0.0), (0.0, 0.15), (0.012, 0.165), (0.055, 0.18), (0.058, 0.172), (0.016, 0.152)]
    pn.lathe(pan, prof, 36, M=T(0, 0.02, 0.47) @ Rx(PI / 2))
    pn.lathe(pan_in, [(0.016, 0.152), (0.014, 0.0)], 36, M=T(0, 0.02, 0.47) @ Rx(PI / 2))
    pn.tube(pan, [(0, -0.01, 0.29), (0, -0.015, 0.22)], 0.018, 8)
    pn.tube(wood, [(0, -0.015, 0.23), (0, -0.02, 0.0)], 0.024, 10)
    pn.build()
    # baseball bat
    bat_w = mat("bat_wood", "#D6A267", 0.5)
    tape = mat("bat_tape", "#1E1E1E", 0.8)
    bt = Part("bat")
    bt.lathe(bat_w, [(-0.02, 0.0), (-0.02, 0.032), (0.0, 0.034), (0.02, 0.02), (0.3, 0.02), (0.5, 0.032),
                     (0.66, 0.045), (0.82, 0.046), (0.85, 0.03), (0.86, 0.0)], 20)
    bt.lathe(tape, [(0.02, 0.0215), (0.22, 0.0215)], 20)
    bt.build()
    # giant hammer: handle along +Z, head axis along Y; strike face at +Y
    hred = mat("hammer_red", "#E2382E", 0.35)
    hmetal = mat("hammer_band", "#B0B4BA", 0.3, 0.8)
    hm = Part("hammer")
    hm.lathe(wood, [(-0.03, 0.0), (-0.03, 0.04), (1.0, 0.04), (1.0, 0.0)], 14)
    hm.lathe(tape, [(0.02, 0.046), (0.32, 0.046)], 14)
    hm.lathe(hred, [(-0.28, 0.0), (-0.28, 0.2), (-0.26, 0.22), (0.26, 0.22), (0.28, 0.2), (0.28, 0.0)], 32,
             M=T(0, 0, 1.12) @ Rx(-PI / 2))
    for yy in (-0.2, 0.2):
        hm.torus(hmetal, (0, yy, 1.12), 0.222, 0.02, 32, 6, M=Rx(PI / 2))
    hm.build()
    # football (pentagon pattern on an icosphere)
    bw = mat("ball_white", "#F7F7F7", 0.4)
    bb = mat("ball_black", "#141414", 0.4)
    bl = Part("ball")
    bl._mi(bw)
    bl._mi(bb)
    res = bmesh.ops.create_icosphere(bl.bm, subdivisions=3, radius=0.11)
    phi = (1 + 5 ** 0.5) / 2
    ico = []
    for a in (-1, 1):
        for b in (-1, 1):
            ico += [V((0, a, b * phi)), V((a, b * phi, 0)), V((b * phi, 0, a))]
    ico = [v.normalized() for v in ico]
    for f in bl.bm.faces:
        c = f.calc_center_median().normalized()
        f.material_index = 1 if max(c.dot(v) for v in ico) > 0.94 else 0
        f.smooth = True
    bl.build()
    # rotten egg
    egg = mat("egg_shell", "#E9DDBF", 0.55)
    eg = Part("egg")
    prof = []
    for i in range(17):
        t = PI * i / 16
        z = -math.cos(t) * 0.062
        r = math.sin(t) * 0.045 * (1.0 - 0.12 * (z / 0.062))
        prof.append((z, r))
    eg.lathe(egg, prof, 20)
    eg.build()
    # firecracker string (鞭炮): crackers fc_i are child nodes so they can pop one by one
    fred = mat("fc_red", "#D81E1E", 0.45)
    fgold = mat("fc_gold", "#F2C14E", 0.4, 0.3)
    cord = mat("fc_cord", "#7A1010", 0.7)
    fuse = mat("fc_fuse", "#3A2A1A", 0.8)
    fc = Part("firecracker")
    fc.tube(cord, [(0, 0, 0.02), (0, 0, -0.62)], 0.006, 6)
    fc.tube(fuse, [(0, 0, 0.0), (0.01, 0, 0.05), (-0.01, 0, 0.1)], 0.005, 6)
    fc_o = fc.build()
    for i in range(12):
        s = 1 if i % 2 == 0 else -1
        c = V((s * 0.032, 0, -0.04 - i * 0.048))
        p = Part("fc_%d" % i, tuple(c))
        Mrot = T(*c) @ Ry(s * 1.0)
        p.lathe(fred, [(-0.038, 0.0), (-0.038, 0.017), (0.038, 0.017), (0.038, 0.0)], 12, M=Mrot)
        p.lathe(fgold, [(-0.04, 0.0), (-0.04, 0.0175), (-0.03, 0.0175), (-0.03, 0.0)], 12, M=Mrot)
        p.build(fc_o)
    # star (dizzy / fx)
    ys = mat("star_yellow", "#FFD84A", 0.3, 0.0, emit=0.6)
    st = Part("star")
    bm = st.bm
    mi = st._mi(ys)
    pts = []
    for i in range(10):
        a = PI / 2 + i * PI / 5
        r = 0.1 if i % 2 == 0 else 0.045
        pts.append((r * math.cos(a), r * math.sin(a)))
    fv = [bm.verts.new((x, -0.02, z)) for (x, z) in pts]
    bv = [bm.verts.new((x, 0.02, z)) for (x, z) in pts]
    cf = bm.verts.new((0, -0.035, 0))
    cb = bm.verts.new((0, 0.035, 0))
    for i in range(10):
        j = (i + 1) % 10
        for vs in ([cf, fv[j], fv[i]], [cb, bv[i], bv[j]], [fv[i], fv[j], bv[j], bv[i]]):
            f = bm.faces.new(vs)
            f.material_index = mi
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    st.build()


# ------------------------------------------------------------------ props
def build_props():
    white = mat("goal_white", "#FAFAFA", 0.4)
    net = mat("goal_net", "#E8E8E8", 0.8)
    gp = Part("goal")
    W, H, Dp = 3.66, 2.44, 2.0
    r = 0.06
    gp.tube(white, [(-W, 0, 0), (-W, 0, H), (W, 0, H), (W, 0, 0)], r, 12)
    gp.tube(white, [(-W, Dp, 0), (W, Dp, 0)], 0.03, 8)
    gp.tube(white, [(-W, 0, H), (-W, 1.0, H), (-W, Dp, 0)], 0.03, 8)
    gp.tube(white, [(W, 0, H), (W, 1.0, H), (W, Dp, 0)], 0.03, 8)
    step = 0.25
    nx = int(2 * W / step)
    for i in range(1, nx):
        x = -W + i * step
        gp.tube(net, [(x, 0, H), (x, 1.0, H), (x, Dp, 0)], 0.007, 4, caps=False)
    # rows across the roof + back slope
    L1 = 1.0
    L2 = math.hypot(Dp - 1.0, H)
    tot = L1 + L2
    for k in range(1, int(tot / step)):
        d = k * step
        if d < L1:
            y, z = d, H
        else:
            f = (d - L1) / L2
            y, z = 1.0 + (Dp - 1.0) * f, H * (1 - f)
        gp.tube(net, [(-W, y, z), (W, y, z)], 0.007, 4, caps=False)
    for s in (-W, W):
        for i in range(1, int(H / step)):
            z = i * step
            ymax = 1.0 + (Dp - 1.0) * (1 - z / H)
            gp.tube(net, [(s, 0, z), (s, ymax, z)], 0.007, 4, caps=False)
        for i in range(1, int(Dp / step)):
            y = i * step
            zmax = H if y <= 1.0 else H * (1 - (y - 1.0) / (Dp - 1.0))
            gp.tube(net, [(s, y, 0), (s, y, zmax)], 0.007, 4, caps=False)
    gp.build()
    # spectator (multimesh source; coloured by shader)
    sp = Part("spectator")
    cm = mat("spec", "#FFFFFF", 0.8)
    sp.lathe(cm, [(0.0, 0.0), (0.0, 0.2), (0.45, 0.22), (0.58, 0.14), (0.6, 0.0)], 6)
    sp.ell(cm, (0, 0, 0.72), (0.12, 0.12, 0.13), 8, 6)
    for s in (1, -1):
        sp.tube(cm, [(s * 0.2, 0, 0.5), (s * 0.28, 0, 0.75), (s * 0.3, 0, 0.95)], 0.05, 4)
    sp.build()


build_turtle()
build_mouse()
reset()
build_fan()
build_tools()
build_props()
export("kit.glb")
print("ALL DONE")
