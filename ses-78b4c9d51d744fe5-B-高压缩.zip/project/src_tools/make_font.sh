#!/bin/sh
# Subsets Noto Sans CJK SC Black down to the characters actually used by the game.
set -e
P=$(dirname "$0")/..
python3 - "$P" << 'PY'
import sys, glob, os
p = sys.argv[1]
chars = set()
for f in glob.glob(os.path.join(p, "scripts", "*.gd")):
    chars |= set(open(f, encoding="utf-8").read())
chars |= set("".join(chr(c) for c in range(0x20, 0x7f)))
chars |= set("！？。，、：；…—～·“”‘’（）《》【】0123456789%")
chars = sorted(c for c in chars if c >= " ")
open("/tmp/font_chars.txt", "w", encoding="utf-8").write("".join(chars))
print(len(chars), "glyphs")
PY
pyftsubset /usr/share/fonts/opentype/noto/NotoSansCJK-Black.ttc --font-number=2 \
  --text-file=/tmp/font_chars.txt --output-file="$P/assets/font.otf" --layout-features='*' --no-hinting
ls -la "$P/assets/font.otf"
