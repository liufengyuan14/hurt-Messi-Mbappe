extends Node
# Drives the game for visual verification: python-free click simulation + screenshots.
var main
var t := 0.0
var step := 0
var plan := []

func _ready():
	main = get_parent()
	plan = [
		[1.0, "shot", "00_start"],
		[1.2, "tool", 0], [1.3, "atk", "head0"], [1.6, "atk", "torso1"], [1.75, "shot", "01_glove"],
		[2.2, "tool", 2], [2.3, "atk", "head0"], [2.62, "shot", "02_pan"],
		[3.2, "tool", 6], [3.3, "atk", "head1"], [3.7, "shot", "03_egg"],
		[4.2, "tool", 4], [4.3, "atk", "head1"], [4.55, "shot", "04_hammer"],
		[5.2, "tool", 3], [5.3, "atk", "torso0"], [5.7, "shot", "05_bat"],
		[6.6, "shot", "06_bat_land"],
		[7.0, "tool", 7], [7.1, "atk", "torso1"], [8.0, "shot", "07_fc"], [10.6, "shot", "08_fc_bang"],
		[11.0, "gang"], [13.0, "shot", "09_gang"], [15.0, "shot", "10_gang2"],
		[15.5, "target", 0], [15.6, "tool", 5], [15.7, "atk", "head0"], [15.86, "shot", "11_ball"],
		[16.0, "spam"], [21.0, "shot", "12_ko"], [22.0, "target", 2], [23.5, "shot", "13_after"],
		[24.0, "heal"], [25.5, "shot", "14_heal"], [26.0, "quit"],
	]

func _process(dt):
	t += dt / maxf(Engine.time_scale, 0.01)
	while step < plan.size() and t >= plan[step][0]:
		_do(plan[step])
		step += 1
	if spam_on and main.cooldown <= 0.0:
		main._use_tool(main.TOOLS[main.tool_i]["id"], main._auto_hit(main.dummies[0]))
		main.cooldown = main.TOOLS[main.tool_i]["cd"]

var spam_on := false

func _do(a):
	match a[1]:
		"shot":
			var img := get_viewport().get_texture().get_image()
			img.save_png("/tmp/shots/%s.png" % a[2])
			print("SHOT ", a[2], " fps=", Engine.get_frames_per_second())
		"tool": main._select_tool(a[2])
		"target": main._select_target(a[2])
		"gang": main._gang_up()
		"heal":
			spam_on = false
			main._heal_all()
		"spam":
			main._select_tool(0)
			spam_on = true
		"atk":
			var s: String = a[2]
			var d = main.dummies[int(s.right(1))]
			var part := s.left(s.length() - 1)
			var p: Vector3 = d.part_center(part)
			main.mouse_pos = main.cam.unproject_position(p)
			main._attack_at(main.mouse_pos)
		"quit": get_tree().quit()
