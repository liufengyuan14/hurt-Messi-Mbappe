# Synthesises every sound effect into one raw PCM bank (assets/sfx.bin).
# Layout: u32 count, then per entry [name: 16 bytes][offset u32][frames u32][loop u32], then int16 mono @22050.
import math, random, struct, sys

SR = 22050
OUT = sys.argv[1] if len(sys.argv) > 1 else "../assets/sfx.bin"
rnd = random.Random(3)


def n(sec):
    return int(sec * SR)


def noise(length):
    return [rnd.uniform(-1, 1) for _ in range(length)]


def lowpass(x, cutoff):
    a = 1 - math.exp(-2 * math.pi * cutoff / SR)
    y, s = [], 0.0
    for v in x:
        s += a * (v - s)
        y.append(s)
    return y


def highpass(x, cutoff):
    lp = lowpass(x, cutoff)
    return [a - b for a, b in zip(x, lp)]


def bandpass(x, lo, hi):
    return lowpass(highpass(x, lo), hi)


def env_exp(length, tau, attack=0.002):
    na = max(1, n(attack))
    return [min(1.0, i / na) * math.exp(-i / SR / tau) for i in range(length)]


def sweep(length, f0, f1, curve=1.0, shape="sin", vib=0.0, vibf=0.0):
    out, ph = [], 0.0
    for i in range(length):
        t = i / length
        f = f0 + (f1 - f0) * (t ** curve)
        if vib:
            f *= 1 + vib * math.sin(2 * math.pi * vibf * i / SR)
        ph += 2 * math.pi * f / SR
        if shape == "sin":
            out.append(math.sin(ph))
        elif shape == "saw":
            out.append(((ph / (2 * math.pi)) % 1.0) * 2 - 1)
        elif shape == "sq":
            out.append(1.0 if math.sin(ph) > 0 else -1.0)
    return out


def mul(a, b):
    return [x * y for x, y in zip(a, b)]


def mix(length, *parts):
    out = [0.0] * length
    for off, sig, g in parts:
        for i, v in enumerate(sig):
            j = off + i
            if j < length:
                out[j] += v * g
    return out


def norm(x, peak=0.9):
    m = max(1e-6, max(abs(v) for v in x))
    return [v / m * peak for v in x]


def fade_out(x, sec=0.01):
    k = n(sec)
    for i in range(min(k, len(x))):
        x[-1 - i] *= i / k
    return x


S = {}

# punch: low thump + click
L = n(0.22)
S["punch"] = norm(mix(L, (0, mul(sweep(L, 160, 45, 0.5), env_exp(L, 0.06)), 1.0),
                      (0, mul(lowpass(noise(n(0.04)), 2500), env_exp(n(0.04), 0.01)), 0.8)))
# slap: bright crack
L = n(0.16)
S["slap"] = norm(mix(L, (0, mul(highpass(noise(L), 1800), env_exp(L, 0.025, 0.0005)), 1.0),
                     (0, mul(sweep(L, 500, 300), env_exp(L, 0.03)), 0.35)))
# clang: frying pan
L = n(1.1)
parts = [(0, mul(highpass(noise(n(0.02)), 2000), env_exp(n(0.02), 0.006)), 0.6)]
for f, g, tau in ((523, 1.0, 0.35), (1247, 0.7, 0.25), (1873, 0.5, 0.2), (2651, 0.35, 0.15), (3420, 0.25, 0.1), (787, 0.5, 0.3)):
    parts.append((0, mul(sweep(L, f, f * 0.995), env_exp(L, tau)), g))
S["clang"] = norm(mix(L, *parts))
# crack: bat
L = n(0.3)
S["crack"] = norm(mix(L, (0, mul(bandpass(noise(n(0.06)), 900, 4000), env_exp(n(0.06), 0.012, 0.0005)), 1.0),
                      (0, mul(sweep(L, 260, 120), env_exp(L, 0.05)), 0.7),
                      (0, mul(sweep(L, 90, 40), env_exp(L, 0.08)), 0.8)))
# boom: giant hammer
L = n(0.75)
S["boom"] = norm(mix(L, (0, mul(sweep(L, 110, 28, 0.4), env_exp(L, 0.18)), 1.0),
                     (0, mul(lowpass(noise(L), 700), env_exp(L, 0.12)), 0.9),
                     (0, mul(highpass(noise(n(0.03)), 1500), env_exp(n(0.03), 0.008)), 0.5)))
# boing: squash spring
L = n(0.7)
S["boing"] = norm(mul(sweep(L, 180, 520, 0.6, "sin", 0.18, 14), env_exp(L, 0.3, 0.01)), 0.6)
# kick: football
L = n(0.18)
S["kick"] = norm(mix(L, (0, mul(sweep(L, 220, 70, 0.4), env_exp(L, 0.04)), 1.0),
                     (0, mul(bandpass(noise(n(0.03)), 600, 3000), env_exp(n(0.03), 0.008)), 0.7)))
L = n(0.1)
S["bounce"] = norm(mul(sweep(L, 300, 150), env_exp(L, 0.03)), 0.5)
# splat: egg
L = n(0.35)
wob = [0.6 + 0.4 * math.sin(2 * math.pi * 23 * i / SR) for i in range(L)]
S["splat"] = norm(mix(L, (0, mul(mul(lowpass(noise(L), 1100), env_exp(L, 0.09, 0.004)), wob), 1.0),
                      (0, mul(highpass(noise(n(0.012)), 3000), env_exp(n(0.012), 0.003)), 0.6),
                      (n(0.02), mul(highpass(noise(n(0.01)), 3000), env_exp(n(0.01), 0.003)), 0.4)))
# pop: single firecracker
L = n(0.12)
S["pop"] = norm(mix(L, (0, mul(noise(L), env_exp(L, 0.018, 0.0003)), 1.0),
                    (0, mul(sweep(L, 180, 60), env_exp(L, 0.03)), 0.6)))
# bang: final explosion
L = n(1.4)
S["bang"] = norm(mix(L, (0, mul(lowpass(noise(L), 900), env_exp(L, 0.35, 0.001)), 1.0),
                     (0, mul(sweep(L, 70, 25, 0.5), env_exp(L, 0.3)), 0.9),
                     (0, mul(noise(n(0.05)), env_exp(n(0.05), 0.01)), 0.8)))
# fuse hiss (loopable-ish)
L = n(1.3)
crackle = [rnd.uniform(-1, 1) if rnd.random() < 0.03 else 0.0 for _ in range(L)]
S["fuse"] = fade_out(norm(mix(L, (0, highpass(noise(L), 3500), 0.5), (0, crackle, 0.8)), 0.45), 0.05)
# whoosh
L = n(0.28)
src = noise(L)
y, s1, s2 = [], 0.0, 0.0
for i, v in enumerate(src):
    t = i / L
    fc = 400 + 2600 * t
    a = 1 - math.exp(-2 * math.pi * fc / SR)
    s1 += a * (v - s1)
    s2 += a * (s1 - s2)
    y.append((s1 - s2) * math.sin(math.pi * t) ** 2)
S["whoosh"] = norm(y, 0.55)
# voices
L = n(0.42)
v = sweep(L, 260, 130, 0.7, "saw", 0.04, 9)
v = bandpass(v, 300, 1500)
S["ow_turtle"] = norm(mul(v, [math.sin(math.pi * min(1, i / L * 1.05)) ** 0.5 for i in range(L)]), 0.8)
L = n(0.3)
pts = []
ph = 0.0
for i in range(L):
    t = i / L
    f = 1300 + 1100 * math.sin(math.pi * t * 0.8) - 500 * t
    f *= 1 + 0.06 * math.sin(2 * math.pi * 30 * i / SR)
    ph += 2 * math.pi * f / SR
    pts.append(math.sin(ph) * math.sin(math.pi * t) ** 0.6)
S["ow_mouse"] = norm(pts, 0.6)
# KO: sad trombone slide
L = n(1.3)
segs = []
notes = [(392, 0.28), (370, 0.28), (349, 0.28), (330, 0.46)]
off = 0
parts = []
for f, d in notes:
    ln = n(d)
    sig = sweep(ln, f, f * (0.9 if d > 0.3 else 1.0), 1.0, "saw", 0.025 if d > 0.3 else 0.0, 6)
    sig = lowpass(sig, 1500)
    e = [min(1, i / n(0.02)) * (1 - i / ln) ** 0.4 for i in range(ln)]
    parts.append((off, mul(sig, e), 1.0))
    off += ln
S["ko"] = norm(mix(L, *parts), 0.7)
# dizzy: tweeting
L = n(1.0)
parts = []
for k in range(6):
    ln = n(0.09)
    parts.append((n(0.15 * k + 0.02), mul(sweep(ln, 2600 + 300 * (k % 2), 3400, 0.5), env_exp(ln, 0.04)), 0.6))
S["dizzy"] = norm(mix(L, *parts), 0.5)
# cheer (one-shot)
L = n(2.2)
cheer = [0.0] * L
for k in range(10):
    base = bandpass(noise(L), 300 + 120 * k, 1400 + 200 * k)
    for i in range(L):
        t = i / L
        cheer[i] += base[i] * (math.sin(math.pi * min(1, t * 1.6)) ** 1.5) * (1 + 0.3 * math.sin(2 * math.pi * (3 + k) * t))
S["cheer"] = norm(cheer, 0.7)
# crowd ambience loop (4 s, crossfaded ends)
L = n(4.0)
amb = bandpass(noise(L + n(0.5)), 250, 1800)
mod = [0.75 + 0.25 * math.sin(2 * math.pi * 0.5 * i / SR) * math.sin(2 * math.pi * 1.3 * i / SR) for i in range(L + n(0.5))]
amb = mul(amb, mod)
X = n(0.5)
loop = amb[:L]
for i in range(X):
    w = i / X
    loop[i] = loop[i] * w + amb[L + i] * (1 - w)
S["crowd"] = norm(loop, 0.5)
# ui click
L = n(0.12)
S["click"] = norm(mix(L, (0, mul(sweep(L, 880, 880), env_exp(L, 0.03)), 1.0), (0, mul(sweep(L, 1320, 1320), env_exp(L, 0.02)), 0.5)), 0.5)
# tooth tink
L = n(0.15)
S["tink"] = norm(mix(L, (0, mul(sweep(L, 3100, 3000), env_exp(L, 0.04)), 1.0), (0, mul(sweep(L, 4700, 4600), env_exp(L, 0.02)), 0.5)), 0.5)
# whistle (referee) for gang-up
L = n(0.7)
w = sweep(L, 2900, 2950, 1.0, "sin", 0.035, 28)
e = [min(1, i / n(0.03)) * (1 if i < L - n(0.08) else (L - i) / n(0.08)) for i in range(L)]
S["whistle"] = norm(mix(L, (0, mul(w, e), 1.0), (0, mul(highpass(noise(L), 2500), e), 0.12)), 0.55)

LOOP = {"crowd"}
names = list(S.keys())
header = struct.pack("<I", len(names))
data = b""
entries = b""
for k in names:
    pcm = struct.pack("<%dh" % len(S[k]), *[max(-32767, min(32767, int(v * 32767))) for v in S[k]])
    entries += k.encode().ljust(16, b"\0") + struct.pack("<III", len(data), len(S[k]), 1 if k in LOOP else 0)
    data += pcm
with open(OUT, "wb") as f:
    f.write(header + entries + data)
print("sfx bank:", len(names), "sounds,", len(data) // 1024, "KB")
