#!/bin/sh
# Full rebuild: textures -> Blender models/icons -> sfx -> font subset -> Godot Web export.
set -e
T=$(cd "$(dirname "$0")" && pwd)
P=$T/..
TMP=/tmp/tex_build
python3 "$T/gen_textures.py" "$TMP"
cp "$TMP/patches.png" "$TMP/grass.png" "$TMP/ads.png" "$TMP/fx.png" "$P/assets/"
blender -b -P "$T/build_assets.py" -- "$P/assets" "$TMP"
xvfb-run -a blender -b -P "$T/render_icons.py" -- "$P/assets/kit.glb" "$P/assets/icons.png"
python3 "$T/gen_sfx.py" "$P/assets/sfx.bin"
sh "$T/make_font.sh"
godot --headless --path "$P" --import
godot --headless --path "$P" --export-release "Web" "$P/../index.html"
