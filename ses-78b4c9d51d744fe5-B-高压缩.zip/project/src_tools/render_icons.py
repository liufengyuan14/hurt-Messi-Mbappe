# Renders the 8 tool icons into one transparent 4x2 atlas.
# blender -b -P render_icons.py -- <kit.glb> <out.png>
import bpy, sys, math
from mathutils import Vector, Euler

argv = sys.argv[sys.argv.index("--") + 1:]
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=argv[0])
sc = bpy.context.scene
ORDER = [
    ("glove", (math.radians(-20), 0, math.radians(-50))),
    ("slipper", (math.radians(-70), math.radians(25), math.radians(-30))),
    ("pan", (math.radians(-60), 0, math.radians(-40))),
    ("bat", (0, math.radians(45), 0)),
    ("hammer", (math.radians(-10), math.radians(35), math.radians(-30))),
    ("ball", (math.radians(20), 0, math.radians(20))),
    ("egg", (0, math.radians(-25), 0)),
    ("firecracker", (0, math.radians(-15), 0)),
]
keep = set(n for n, _ in ORDER)
for o in list(bpy.data.objects):
    root = o
    while root.parent:
        root = root.parent
    if root.name.split(".")[0] not in keep:
        bpy.data.objects.remove(o, do_unlink=True)


def world_bounds(root):
    pts = []
    stack = [root]
    while stack:
        o = stack.pop()
        stack.extend(o.children)
        if o.type == "MESH":
            pts += [o.matrix_world @ Vector(c) for c in o.bound_box]
    mn = Vector((min(p.x for p in pts), min(p.y for p in pts), min(p.z for p in pts)))
    mx = Vector((max(p.x for p in pts), max(p.y for p in pts), max(p.z for p in pts)))
    return mn, mx


for i, (name, rot) in enumerate(ORDER):
    ob = bpy.data.objects[name]
    ob.rotation_mode = "XYZ"
    ob.rotation_euler = Euler(rot)
    ob.location = (0, 0, 0)
    ob.scale = (1, 1, 1)
    bpy.context.view_layer.update()
    mn, mx = world_bounds(ob)
    size = max(mx.x - mn.x, mx.z - mn.z)
    s = 0.86 / size
    ob.scale = (s, s, s)
    bpy.context.view_layer.update()
    mn, mx = world_bounds(ob)
    c = (mn + mx) / 2
    cx = (i % 4) - 1.5
    cz = 0.5 - (i // 4)
    ob.location = (cx - c.x, -c.y, cz - c.z)

cam = bpy.data.objects.new("cam", bpy.data.cameras.new("cam"))
sc.collection.objects.link(cam)
sc.camera = cam
cam.data.type = "ORTHO"
cam.data.ortho_scale = 4.0
cam.location = (0, -10, 0)
cam.rotation_euler = (math.radians(90), 0, 0)
w = bpy.data.worlds.new("w")
sc.world = w
w.use_nodes = True
w.node_tree.nodes["Background"].inputs[0].default_value = (0.8, 0.85, 0.9, 1)
w.node_tree.nodes["Background"].inputs[1].default_value = 1.0
sun = bpy.data.objects.new("sun", bpy.data.lights.new("sun", "SUN"))
sc.collection.objects.link(sun)
sun.rotation_euler = (math.radians(60), math.radians(-20), math.radians(-35))
sun.data.energy = 3.5
sc.render.film_transparent = True
sc.render.resolution_x = 1024
sc.render.resolution_y = 512
sc.render.image_settings.color_mode = "RGBA"
sc.render.filepath = argv[1]
bpy.ops.render.render(write_still=True)
